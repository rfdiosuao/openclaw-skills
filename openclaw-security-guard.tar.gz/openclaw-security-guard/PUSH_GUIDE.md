# 🚀 OpenClaw Security Guard - GitHub 推送指南

## 📋 推送步骤

### 方式 1：使用 GitHub Token（推荐）

#### 1. 获取 GitHub Token

1. 访问 https://github.com/settings/tokens
2. 点击 **Generate new token (classic)**
3. 勾选权限：`repo` (全选)
4. 生成并复制 Token（格式：`ghp_xxxxxxxxxxxx`）

#### 2. 配置 Token

**临时配置（当前会话）：**
```bash
export GITHUB_TOKEN="ghp_你的 Token"
```

**永久配置（添加到 ~/.bashrc）：**
```bash
echo 'export GITHUB_TOKEN="ghp_你的 Token"' >> ~/.bashrc
source ~/.bashrc
```

#### 3. 推送代码

```bash
cd ~/openclaw-skills/openclaw-security-guard

# 使用 Token 推送
git push https://$GITHUB_TOKEN@github.com/openclaw-cn/openclaw-security-guard.git main
```

---

### 方式 2：使用 SSH Key

#### 1. 生成 SSH Key

```bash
ssh-keygen -t ed25519 -C "your-email@example.com"
```

#### 2. 添加到 GitHub

1. 复制公钥：`cat ~/.ssh/id_ed25519.pub`
2. 访问 https://github.com/settings/keys
3. 点击 **New SSH key**
4. 粘贴公钥并保存

#### 3. 切换为 SSH 协议

```bash
cd ~/openclaw-skills/openclaw-security-guard
git remote set-url origin git@github.com:openclaw-cn/openclaw-security-guard.git
git push -u origin main
```

---

### 方式 3：手动创建仓库后推送

#### 1. 在 GitHub 创建仓库

1. 访问 https://github.com/new
2. 仓库名：`openclaw-security-guard`
3. 所有者：`openclaw-cn`
4. 公开仓库（Public）
5. **不要** 初始化 README/.gitignore
6. 点击 **Create repository**

#### 2. 推送代码

```bash
cd ~/openclaw-skills/openclaw-security-guard

# 如果提示认证，输入 GitHub 用户名和 Token
git remote set-url origin https://github.com/openclaw-cn/openclaw-security-guard.git
git push -u origin main
```

---

## 🔧 快速推送脚本

创建 `push-to-github.sh`：

```bash
#!/bin/bash

# 检查 Token
if [ -z "$GITHUB_TOKEN" ]; then
    echo "❌ GITHUB_TOKEN 未设置"
    echo "请运行：export GITHUB_TOKEN=\"ghp_xxx\""
    exit 1
fi

cd ~/openclaw-skills/openclaw-security-guard

echo "🚀 推送到 GitHub..."
git push https://$GITHUB_TOKEN@github.com/openclaw-cn/openclaw-security-guard.git main

if [ $? -eq 0 ]; then
    echo "✅ 推送成功！"
    echo "📦 仓库地址：https://github.com/openclaw-cn/openclaw-security-guard"
else
    echo "❌ 推送失败"
    exit 1
fi
```

使用方法：
```bash
chmod +x push-to-github.sh
export GITHUB_TOKEN="ghp_xxx"
./push-to-github.sh
```

---

## ✅ 验证推送

推送成功后，访问：
https://github.com/openclaw-cn/openclaw-security-guard

检查文件是否完整：
- SKILL.md
- skill.json
- package.json
- README.md
- src/ 目录
- references/ 目录

---

## 📤 发布到 ClawHub

推送成功后，可以发布到 ClawHub：

```bash
# 登录
claw login --token clh_wfoNYpWcWq0gNC7X0DfsbL2cW3Ayba7jxmGaNf_3IU0

# 发布
cd ~/openclaw-skills/openclaw-security-guard
claw skill publish

# 验证
claw skill my
```

---

## 🐛 常见问题

### Q1: 认证失败

**错误：** `Authentication failed`

**解决：**
```bash
# 确保 Token 正确
export GITHUB_TOKEN="ghp_你的完整 Token"

# 重新推送
git push https://$GITHUB_TOKEN@github.com/openclaw-cn/openclaw-security-guard.git main
```

### Q2: 仓库不存在

**错误：** `Repository not found`

**解决：**
1. 手动在 GitHub 创建仓库
2. 确保仓库名为 `openclaw-security-guard`
3. 确保所有者为 `openclaw-cn`

### Q3: 权限不足

**错误：** `Permission denied`

**解决：**
- 确保你是 `openclaw-cn` 组织成员
- 或有仓库写入权限
- 或使用个人账号推送

---

*最后更新：2026-03-11*
