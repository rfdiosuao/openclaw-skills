---
id: openclaw-cn/openclaw-security-guard
owner_id: openclaw-cn
name: OpenClaw 安全卫士
description: 自动检测 OpenClaw 安装和配置中的关键安全风险，及时提醒管理员并修复
version: 1.0.0
icon: "🛡️"
author: OpenClaw 中文社区
metadata:
  clawdbot:
    emoji: "🛡️"
    requires:
      bins:
        - node
        - openclaw
    install:
      - id: node
        kind: node
        package: '@openclaw-cn/security-guard'
        label: 安装安全检测依赖
---

# 🛡️ OpenClaw Security Guard

OpenClaw 安全风险自动检测工具，基于官方安全文档全面扫描配置风险。

## 🔍 功能特性

- **16 项核心风险检测** - 覆盖文件权限、网络暴露、认证授权、工具执行等
- **自动分级告警** - 严重/警告/信息三级分类
- **一键修复建议** - 提供具体修复命令和配置示例
- **定时巡检** - 支持心跳任务定期检测
- **告警通知** - 发现严重风险时主动提醒管理员

## 📦 安装

```bash
# 通过 Claw-CLI 安装
claw skill install openclaw-cn/openclaw-security-guard
```

## 🚀 使用方法

### 快速检测

```bash
# 执行全面安全审计
claw security-guard audit

# 快速检测（仅关键项）
claw security-guard quick-check

# 生成检测报告
claw security-guard report

# 自动修复可修复的问题
claw security-guard fix --all
```

### 专项检测

```bash
# 检查文件权限
claw security-guard check fs-perms

# 检查网络配置
claw security-guard check network

# 检查认证配置
claw security-guard check auth

# 检查沙箱配置
claw security-guard check sandbox

# 检查工具策略
claw security-guard check tools
```

### 配置巡检

```bash
# 添加定时巡检任务
claw security-guard schedule add --daily 02:00

# 查看巡检计划
claw security-guard schedule list

# 移除巡检任务
claw security-guard schedule remove <id>
```

## 📊 检测项说明

### 严重风险（Critical）

| 检测项 | 说明 | 修复方法 |
|--------|------|----------|
| `fs.state_dir.perms_world_writable` | 状态目录可写 | `chmod 700 ~/.openclaw` |
| `fs.config.perms_writable` | 配置文件可写 | `chmod 600 ~/.openclaw/openclaw.json` |
| `fs.config.perms_world_readable` | 配置文件可读 | `chmod 600 ~/.openclaw/openclaw.json` |
| `gateway.bind_no_auth` | Gateway 无认证 | 配置 `gateway.auth.mode: "token"` |
| `gateway.tailscale_funnel` | Tailscale Funnel 暴露 | 禁用 Funnel 模式 |
| `security.exposure.open_groups_with_elevated` | 开放群组 + 提权 | 限制群组或禁用提权 |
| `sandbox.dangerous_network_mode` | 沙箱网络模式危险 | 设置 `network: "none"` |

### 警告风险（Warning）

| 检测项 | 说明 | 修复方法 |
|--------|------|----------|
| `tools.exec.host_sandbox_no_sandbox` | Exec 无沙箱 | 启用沙箱或设置 `security: "ask"` |
| `logging.redact_off` | 日志未脱敏 | 启用 `logging.redactSensitive: true` |
| `gateway.lan_bind` | LAN 绑定 | 改为 `loopback` 或配置认证 |

## 📖 示例

### 示例 1：执行全面检测

```bash
$ claw security-guard audit

🛡️ OpenClaw 安全检测报告
═══════════════════════════════════════

📊 检测概览
- 检测项：16
- 严重：2
- 警告：3
- 信息：5
- 通过：6

🔴 严重风险
───────────
[1] fs.config.perms_writable
    问题：配置文件可被其他用户修改
    风险：攻击者可能篡改认证配置
    修复：chmod 600 ~/.openclaw/openclaw.json
    
[2] gateway.bind_no_auth
    问题：Gateway 绑定到 0.0.0.0 但无认证
    风险：任何人可控制你的 OpenClaw
    修复：配置 gateway.auth.mode: "token"

🟡 警告风险
───────────
[1] tools.exec.host_sandbox_no_sandbox
    问题：Exec 工具未启用沙箱
    建议：设置 exec.security: "ask"

✅ 修复建议
───────────
运行以下命令自动修复：
claw security-guard fix --critical
```

### 示例 2：生成 JSON 报告

```bash
$ claw security-guard report --json

{
  "timestamp": "2026-03-11T15:30:00+08:00",
  "summary": {
    "total": 16,
    "critical": 2,
    "warning": 3,
    "info": 5,
    "passed": 6
  },
  "findings": [
    {
      "id": "fs.config.perms_writable",
      "severity": "critical",
      "status": "failed",
      "message": "配置文件权限不当",
      "remediation": "chmod 600 ~/.openclaw/openclaw.json"
    }
  ]
}
```

### 示例 3：自动修复

```bash
$ claw security-guard fix --all

🔧 开始自动修复...

[1/2] 修复文件权限...
    ✓ chmod 700 ~/.openclaw
    ✓ chmod 600 ~/.openclaw/openclaw.json

[2/2] 更新安全配置...
    ✓ 启用 gateway.auth
    ✓ 启用 logging.redactSensitive

✅ 修复完成！2 个问题已解决
```

## 🔔 告警通知

当检测到严重风险时，Skill 会主动通知管理员：

```bash
# 配置告警渠道
claw security-guard alert config --channel feishu --user ou_xxx

# 测试告警
claw security-guard alert test

# 查看告警历史
claw security-guard alert history
```

## 📋 心跳任务配置

在 `HEARTBEAT.md` 中添加：

```markdown
### 安全检查（每日 02:00）
- [ ] **执行安全审计** - `claw security-guard audit --quiet`
- [ ] **检查严重风险** - 发现 critical 立即告警
- [ ] **生成周报** - 每周日生成安全周报
```

## 🔒 安全最佳实践

### 最小安全配置

```json
{
  "gateway": {
    "mode": "local",
    "bind": "loopback",
    "auth": { "mode": "token", "token": "your-long-random-token" }
  },
  "session": {
    "dmScope": "per-channel-peer"
  },
  "tools": {
    "profile": "messaging",
    "deny": ["group:automation", "group:runtime", "group:fs"],
    "fs": { "workspaceOnly": true },
    "exec": { "security": "deny", "ask": "always" },
    "elevated": { "enabled": false }
  },
  "agents": {
    "defaults": {
      "sandbox": { "mode": "non-main" }
    }
  }
}
```

### 日常检查命令

```bash
# 快速状态检查
openclaw status

# 安全审计
openclaw security audit

# 检查配对请求
openclaw pairing list

# 查看会话
openclaw sessions list
```

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📄 许可证

MIT License

## 🔗 相关资源

- [OpenClaw 安全文档](https://docs.openclaw.ai/gateway/security)
- [OpenClaw 安装风险完整指南](https://my.feishu.cn/docx/Nr4ZdwfXxoZyo2xyKoIcheKXn6d)
- [GitHub 仓库](https://github.com/openclaw-cn/openclaw-security-guard)
