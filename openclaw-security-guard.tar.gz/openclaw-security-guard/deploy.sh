#!/bin/bash

# 🛡️ OpenClaw Security Guard 快速部署脚本

set -e

SKILL_NAME="openclaw-security-guard"
SKILL_DIR="$HOME/openclaw-skills/$SKILL_NAME"
CLAW_TOKEN="${CLAWHUB_API_KEY:-}"

echo "🛡️  OpenClaw Security Guard 部署脚本"
echo "═══════════════════════════════════════"
echo ""

# 检查是否已登录 Claw-CLI
echo "📋 检查环境..."
if ! command -v claw &> /dev/null; then
    echo "❌ Claw-CLI 未安装"
    echo "请先运行：npm install -g @openclaw-cn/cli"
    exit 1
fi

# 检查是否已登录
if ! claw whoami &> /dev/null; then
    echo "⚠️  未登录 Claw-CLI"
    if [ -n "$CLAW_TOKEN" ]; then
        echo "🔐 使用环境变量登录..."
        claw login --token "$CLAW_TOKEN"
    else
        echo "请登录 Claw-CLI:"
        echo "claw login --token <your-token>"
        exit 1
    fi
fi

echo "✅ Claw-CLI 已登录"
echo ""

# 检查 Skill 目录
if [ ! -d "$SKILL_DIR" ]; then
    echo "❌ Skill 目录不存在：$SKILL_DIR"
    exit 1
fi

cd "$SKILL_DIR"

# 安装依赖
echo "📦 安装依赖..."
npm install

# 编译
echo "🔧 编译代码..."
npm run build

# 检查编译结果
if [ ! -d "dist" ]; then
    echo "❌ 编译失败，dist 目录不存在"
    exit 1
fi

echo "✅ 编译成功"
echo ""

# 推送到 GitHub
echo "🚀 推送到 GitHub..."
if git remote -v | grep -q origin; then
    git add .
    git commit -m "chore: 自动部署" || echo "无更改"
    git push origin main
    echo "✅ 已推送到 GitHub"
else
    echo "⚠️  未配置远程仓库"
    echo "请手动添加远程仓库:"
    echo "git remote add origin https://github.com/openclaw-cn/$SKILL_NAME.git"
    echo "git push -u origin main"
fi
echo ""

# 发布到 ClawHub
echo "📤 发布到 ClawHub..."
claw skill publish

echo ""
echo "✅ 部署完成！"
echo ""
echo "📊 验证发布:"
echo "claw skill my"
echo ""
echo "🔍 查看 Skill:"
echo "claw skill info openclaw-cn/$SKILL_NAME"
echo ""
