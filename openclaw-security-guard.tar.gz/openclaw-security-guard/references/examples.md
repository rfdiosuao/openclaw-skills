# 📖 使用示例

## 快速开始

### 1. 安装 Skill

```bash
claw skill install openclaw-cn/openclaw-security-guard
```

### 2. 执行首次检测

```bash
# 全面审计
security-guard audit

# 或快速检查
security-guard quick-check
```

### 3. 查看结果

典型输出：

```
🛡️  OpenClaw 安全检测报告
═══════════════════════════════════════

📊 检测概览
- 检测项：16
- 严重：2
- 警告：3
- 信息：5
- 通过：6

🔴 严重风险
───────────
[1] fs.config.perms_writable
    问题：配置文件权限为 644，可能被未授权访问
    修复：chmod 600 ~/.openclaw/openclaw.json
    
[2] gateway.bind_no_auth
    问题：Gateway 绑定到 0.0.0.0 但无认证
    风险：任何人可控制你的 OpenClaw
    修复：配置 gateway.auth.mode: "token"

🟡 警告风险
───────────
[1] tools.exec.host_sandbox_no_sandbox
    问题：Exec 工具未配置安全限制
    建议：设置 tools.exec.security: "ask"
```

### 4. 自动修复

```bash
# 修复所有可修复的问题
security-guard fix --all

# 或仅修复严重问题
security-guard fix --critical
```

---

## 日常使用场景

### 场景 1：每日安全巡检

在 `HEARTBEAT.md` 中配置：

```markdown
### 安全检查（每日 02:00）
- [ ] **执行安全审计** - `security-guard audit --quiet`
- [ ] **检查严重风险** - 发现 critical 立即告警
```

### 场景 2：配置变更后检查

修改 OpenClaw 配置后，立即检查：

```bash
# 快速验证配置安全性
security-guard quick-check

# 或专项检查
security-guard check auth      # 检查认证
security-guard check network   # 检查网络
security-guard check sandbox   # 检查沙箱
```

### 场景 3：生成安全报告

```bash
# 生成 Markdown 报告
security-guard report --format markdown -o security-report.md

# 生成 JSON 报告（用于自动化）
security-guard report --format json -o report.json

# 查看报告
cat security-report.md
```

### 场景 4：自动修复配置

```bash
# 模拟运行（查看将执行的操作）
security-guard fix --dry-run

# 实际修复
security-guard fix --all

# 验证修复结果
security-guard audit
```

---

## 专项检查示例

### 检查文件权限

```bash
security-guard check fs-perms
```

输出：
```
📊 检测概览
- 检测项：2
- 严重：0
- 警告：0
- 信息：0
- 通过：2

✅ 所有安全检查通过！
```

### 检查网络配置

```bash
security-guard check network
```

输出：
```
📊 检测概览
- 检测项：2
- 严重：1
- 警告：0
- 信息：1
- 通过：0

🔴 严重风险
───────────
[1] gateway.bind_no_auth
    问题：Gateway 绑定到 0.0.0.0 但无认证
    修复：配置 gateway.bind: "loopback" 或启用认证
```

### 检查认证配置

```bash
security-guard check auth
```

---

## 告警配置示例

### 配置飞书告警

```bash
security-guard alert config --channel feishu --user ou_9822a6c7f8a0ee947a95b0f212c6a85e
```

### 测试告警

```bash
security-guard alert test
```

### 查看告警历史

```bash
security-guard alert history
```

---

## 定时任务示例

### 添加每日巡检

```bash
security-guard schedule add --daily 02:00
```

然后在 `HEARTBEAT.md` 中添加：

```markdown
### 安全检查（每日 02:00）
- [ ] 执行安全审计 - `security-guard audit --quiet`
- [ ] 检查严重风险 - 发现 critical 立即告警
```

### 添加每周报告

```markdown
### 安全周报（每周日 09:00）
- [ ] 生成安全周报 - `security-guard report --format markdown -o weekly-report.md`
```

---

## JSON 输出示例

```bash
security-guard audit --json
```

输出：

```json
{
  "timestamp": "2026-03-11T15:30:00.000Z",
  "summary": {
    "total": 16,
    "critical": 2,
    "warning": 3,
    "info": 5,
    "passed": 6
  },
  "findings": [
    {
      "id": "fs.config.perms_writable",
      "name": "配置文件权限",
      "severity": "critical",
      "status": "failed",
      "message": "配置文件权限为 644，可能被未授权访问",
      "remediation": "chmod 600 ~/.openclaw/openclaw.json",
      "command": "chmod 600 ~/.openclaw/openclaw.json"
    }
  ]
}
```

---

## 自动化集成

### GitHub Actions

```yaml
name: Security Audit

on:
  schedule:
    - cron: '0 2 * * *'  # 每天 02:00

jobs:
  audit:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Install Security Guard
        run: npm install -g @openclaw-cn/security-guard
      
      - name: Run Audit
        run: security-guard audit --json > report.json
      
      - name: Upload Report
        uses: actions/upload-artifact@v3
        with:
          name: security-report
          path: report.json
```

### Cron 定时任务

```bash
# 编辑 crontab
crontab -e

# 添加每日检查
0 2 * * * /usr/bin/security-guard audit --quiet >> /var/log/security-audit.log 2>&1
```

---

## 故障排查

### 问题 1：命令未找到

```bash
# 确保已安装
npm install -g @openclaw-cn/security-guard

# 检查 PATH
echo $PATH

# 重新链接
npm link
```

### 问题 2：无法访问配置文件

```bash
# 检查文件是否存在
ls -la ~/.openclaw/openclaw.json

# 检查权限
chmod 600 ~/.openclaw/openclaw.json
```

### 问题 3：检测失败

```bash
# 查看详细错误
security-guard audit --verbose

# 检查 OpenClaw 安装
openclaw status
```

---

## 最佳实践

1. **每日巡检** - 配置心跳任务每日检查
2. **配置变更后检查** - 每次修改配置后立即检查
3. **定期生成报告** - 每周生成安全报告存档
4. **及时修复** - 发现严重风险立即修复
5. **告警通知** - 配置告警渠道，及时响应

---

*最后更新：2026-03-11*
