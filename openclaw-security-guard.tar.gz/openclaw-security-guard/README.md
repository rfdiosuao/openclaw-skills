# 🛡️ OpenClaw Security Guard

> **OpenClaw 安全风险自动检测工具** — 基于官方安全文档，全面扫描配置风险，及时告警并修复

[![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)](https://clawhub.ai/skills/openclaw-cn/openclaw-security-guard)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![ClawHub](https://img.shields.io/badge/ClawHub-openclaw--cn/openclaw--security--guard-orange)](https://clawhub.ai/skills/openclaw-cn/openclaw-security-guard)

---

## 📖 简介

**OpenClaw Security Guard** 是基于 OpenClaw 官方安全文档开发的专业安全检测工具，能够自动扫描 16 项核心安全风险，及时发现配置问题并提供修复建议。

### ✨ 核心能力

- 🔍 **16 项核心检测** — 覆盖文件权限、网络暴露、认证授权、工具执行、沙箱隔离等
- 🚨 **分级告警** — 严重/警告/信息三级分类，优先处理关键问题
- 🔧 **一键修复** — 自动修复常见问题，提供详细修复命令
- ⏰ **定时巡检** — 支持心跳任务，每日自动检测
- 📢 **主动告警** — 发现严重风险时立即通知管理员
- 📊 **多格式报告** — 支持 Text/JSON/Markdown 格式

---

## 🚀 快速开始

### 安装

```bash
# 通过 Claw-CLI 安装
claw skill install openclaw-cn/openclaw-security-guard
```

### 使用

```bash
# 执行全面检测
security-guard audit

# 快速检查（仅关键项）
security-guard quick-check

# 自动修复
security-guard fix --all
```

### 典型输出

```
🛡️  OpenClaw 安全检测报告
═══════════════════════════════════════

📊 检测概览
- 检测项：16
- 🔴 严重：2
- 🟡 警告：3
- ℹ️ 信息：5
- ✅ 通过：6

🔴 严重风险
───────────
[1] fs.config.perms_writable
    问题：配置文件权限为 644，可能被未授权访问
    修复：chmod 600 ~/.openclaw/openclaw.json
    
[2] gateway.bind_no_auth
    问题：Gateway 绑定到 0.0.0.0 但无认证
    风险：任何人可控制你的 OpenClaw
    修复：配置 gateway.auth.mode: "token"
```

---

## 📋 目录

- [功能特性](#-功能特性)
- [安装](#-安装)
- [使用指南](#-使用指南)
- [检测项说明](#-检测项说明)
- [配置示例](#-配置示例)
- [自动化集成](#-自动化集成)
- [贡献](#-贡献)
- [许可证](#-许可证)

---

## ✨ 功能特性

### 全面检测

基于 OpenClaw 官方安全文档，实现 16 项核心检测：

| 类别 | 检测项 | 说明 |
|------|--------|------|
| **文件系统** | `fs.state_dir.perms_world_writable` | 状态目录权限 |
| | `fs.config.perms_writable` | 配置文件权限 |
| **Gateway** | `gateway.auth_missing` | 认证配置 |
| | `gateway.bind_no_auth` | 绑定配置 |
| | `gateway.tailscale_funnel` | Tailscale Funnel |
| **沙箱** | `sandbox.dangerous_network_mode` | 网络模式 |
| | `sandbox.mode_off` | 沙箱启用状态 |
| **工具** | `tools.exec.host_sandbox_no_sandbox` | Exec 安全 |
| | `tools.elevated.enabled` | Elevated 模式 |
| | `tools.profile_full` | 权限配置 |
| **会话** | `session.dm_scope_shared` | DM 隔离 |
| **日志** | `logging.redact_off` | 脱敏配置 |
| **插件** | `plugins.allowlist_missing` | 允许列表 |
| **浏览器** | `browser.ssrf.allow_private` | SSRF 策略 |
| **节点** | `gateway.nodes.allow_commands_dangerous` | 命令限制 |

### 自动修复

支持一键修复常见问题：

```bash
# 修复所有可修复的问题
security-guard fix --all

# 仅修复严重问题
security-guard fix --critical

# 模拟运行（不实际修改）
security-guard fix --dry-run
```

### 多种报告格式

```bash
# 文本报告（默认）
security-guard report

# JSON 格式
security-guard report --format json -o report.json

# Markdown 格式
security-guard report --format markdown -o report.md

# 保存到文件
security-guard report -o security-report.md
```

---

## 📦 安装

### 通过 Claw-CLI 安装（推荐）

```bash
claw skill install openclaw-cn/openclaw-security-guard
```

### 手动安装

```bash
# 克隆仓库
git clone https://github.com/openclaw-cn/openclaw-security-guard.git
cd openclaw-security-guard

# 安装依赖
npm install

# 编译
npm run build

# 全局链接
npm link
```

### 从源码构建

```bash
# 安装依赖
npm install

# 编译
npm run build

# 运行
node dist/index.js audit
```

---

## 📖 使用指南

### 全面审计

```bash
# 执行全面审计
security-guard audit

# 深度审计（包含实时探测）
security-guard audit --deep

# JSON 格式输出
security-guard audit --json

# 静默模式
security-guard audit --quiet
```

### 专项检查

```bash
# 检查文件权限
security-guard check fs-perms

# 检查网络配置
security-guard check network

# 检查认证配置
security-guard check auth

# 检查沙箱配置
security-guard check sandbox

# 检查工具策略
security-guard check tools
```

### 生成报告

```bash
# 生成文本报告
security-guard report

# 生成 JSON 报告
security-guard report --format json -o report.json

# 生成 Markdown 报告
security-guard report --format markdown -o report.md
```

### 告警管理

```bash
# 配置告警渠道
security-guard alert config --channel feishu --user ou_xxx

# 测试告警
security-guard alert test

# 查看告警历史
security-guard alert history
```

### 定时巡检

```bash
# 添加每日巡检任务
security-guard schedule add --daily 02:00

# 查看巡检计划
security-guard schedule list
```

---

## 📊 检测项说明

### 严重风险（Critical）

| 检测项 | 说明 | 修复方法 |
|--------|------|----------|
| `fs.state_dir.perms_world_writable` | 状态目录可写 | `chmod 700 ~/.openclaw` |
| `fs.config.perms_writable` | 配置文件可写 | `chmod 600 ~/.openclaw/openclaw.json` |
| `gateway.auth_missing` | Gateway 无认证 | 配置 `gateway.auth.mode: "token"` |
| `gateway.bind_no_auth` | Gateway 暴露无认证 | 绑定 loopback 或启用认证 |
| `gateway.tailscale_funnel` | Tailscale Funnel 暴露 | 禁用 Funnel 模式 |
| `sandbox.dangerous_network_mode` | 沙箱网络模式危险 | 设置 `network: "none"` |

### 警告风险（Warning）

| 检测项 | 说明 | 修复方法 |
|--------|------|----------|
| `tools.exec.host_sandbox_no_sandbox` | Exec 无沙箱 | 设置 `security: "ask"` |
| `tools.elevated.enabled` | Elevated 模式启用 | 设置 `enabled: false` |
| `sandbox.mode_off` | 沙箱未启用 | 设置 `mode: "non-main"` |
| `logging.redact_off` | 日志未脱敏 | 启用 `redactSensitive: true` |

---

## 🔧 配置示例

### 最小安全配置

```json
{
  "gateway": {
    "mode": "local",
    "bind": "loopback",
    "port": 18789,
    "auth": {
      "mode": "token",
      "token": "your-long-random-token"
    }
  },
  "session": {
    "dmScope": "per-channel-peer"
  },
  "tools": {
    "profile": "messaging",
    "deny": ["group:automation", "group:runtime", "group:fs"],
    "fs": { "workspaceOnly": true },
    "exec": {
      "security": "deny",
      "ask": "always"
    },
    "elevated": { "enabled": false }
  },
  "agents": {
    "defaults": {
      "sandbox": { "mode": "non-main" }
    }
  },
  "logging": {
    "redactSensitive": true
  }
}
```

### 心跳任务配置

在 `HEARTBEAT.md` 中添加：

```markdown
### 安全检查（每日 02:00）
- [ ] **执行安全审计** - `security-guard audit --quiet`
- [ ] **检查严重风险** - 发现 critical 立即告警
- [ ] **生成周报** - 每周日生成安全周报
```

---

## 🤖 自动化集成

### GitHub Actions

```yaml
name: Security Audit

on:
  schedule:
    - cron: '0 2 * * *'  # 每天 02:00

jobs:
  audit:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Install Security Guard
        run: npm install -g @openclaw-cn/security-guard
      
      - name: Run Audit
        run: security-guard audit --json > report.json
      
      - name: Upload Report
        uses: actions/upload-artifact@v3
        with:
          name: security-report
          path: report.json
```

### Cron 定时任务

```bash
# 编辑 crontab
crontab -e

# 添加每日检查
0 2 * * * /usr/bin/security-guard audit --quiet >> /var/log/security-audit.log 2>&1
```

---

## 🧪 开发

### 本地开发

```bash
# 克隆仓库
git clone https://github.com/openclaw-cn/openclaw-security-guard.git
cd openclaw-security-guard

# 安装依赖
npm install

# 开发模式
npm run dev

# 运行测试
npm test

# 编译
npm run build
```

### 项目结构

```
openclaw-security-guard/
├── src/
│   ├── index.ts          # 主入口（CLI 命令）
│   ├── auditor.ts        # 核心检测逻辑（16 项检测）
│   ├── reporter.ts       # 报告生成器
│   ├── fixer.ts          # 自动修复器
│   └── alert.ts          # 告警管理器
├── references/
│   └── examples.md       # 使用示例
├── tests/
├── SKILL.md              # ClawHub 格式说明
├── skill.json            # Skill 元数据
├── package.json          # NPM 配置
├── tsconfig.json         # TypeScript 配置
└── README.md             # 本文档
```

---

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

### 贡献流程

1. Fork 本仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

### 贡献指南

- 遵循现有的代码风格
- 添加必要的测试
- 更新文档
- 确保所有测试通过

---

## 📄 许可证

MIT License - 详见 [LICENSE](LICENSE) 文件

---

## 🔗 相关资源

- **[OpenClaw 官方文档](https://docs.openclaw.ai)** - 完整文档
- **[OpenClaw 安全文档](https://docs.openclaw.ai/gateway/security)** - 安全指南
- **[ClawHub 市场](https://clawhub.ai/skills/openclaw-cn/openclaw-security-guard)** - Skill 详情
- **[OpenClaw 安装风险完整指南](https://my.feishu.cn/docx/Nr4ZdwfXxoZyo2xyKoIcheKXn6d)** - 风险文档
- **[Discord 社区](https://discord.com/invite/clawd)** - 社区支持

---

## 📞 支持

遇到问题？

- 📝 提交 [Issue](https://github.com/openclaw-cn/openclaw-security-guard/issues)
- 💬 加入 [Discord 社区](https://discord.com/invite/clawd)
- 📖 访问 [OpenClaw 论坛](https://clawd.org.cn/forum/)

---

## 📈 Star History

[![Star History Chart](https://api.star-history.com/svg?repos=openclaw-cn/openclaw-security-guard&type=Date)](https://star-history.com/#openclaw-cn/openclaw-security-guard&Date)

---

*最后更新：2026-03-11*  
*维护者：OpenClaw 中文社区*
