#!/bin/bash

# 🚀 一键推送到 GitHub 脚本

set -e

REPO_OWNER="openclaw-cn"
REPO_NAME="openclaw-security-guard"
SKILL_DIR="$HOME/openclaw-skills/$REPO_NAME"

echo "🚀 OpenClaw Security Guard - GitHub 推送脚本"
echo "═══════════════════════════════════════"
echo ""

# 检查 Token
if [ -z "$GITHUB_TOKEN" ]; then
    echo "⚠️  GITHUB_TOKEN 未设置"
    echo ""
    echo "请按以下步骤操作："
    echo ""
    echo "1. 访问 https://github.com/settings/tokens"
    echo "2. 生成新 Token（勾选 repo 权限）"
    echo "3. 复制 Token 并运行："
    echo ""
    echo "   export GITHUB_TOKEN=\"ghp_xxxxxxxxxxxx\""
    echo ""
    echo "然后重新运行此脚本"
    echo ""
    
    # 尝试从 ~/.bashrc 读取
    if grep -q "GITHUB_TOKEN" ~/.bashrc 2>/dev/null; then
        echo "💡 检测到 ~/.bashrc 中有 GITHUB_TOKEN 配置"
        echo "运行 source ~/.bashrc 后重试"
        echo ""
        source ~/.bashrc
        if [ -n "$GITHUB_TOKEN" ]; then
            echo "✅ Token 已加载"
        else
            exit 1
        fi
    else
        exit 1
    fi
fi

# 检查目录
if [ ! -d "$SKILL_DIR" ]; then
    echo "❌ Skill 目录不存在：$SKILL_DIR"
    exit 1
fi

cd "$SKILL_DIR"

# 检查 Git 状态
echo "📋 检查 Git 状态..."
git status

# 提交未提交的更改
if ! git diff --quiet; then
    echo "📝 提交未提交的更改..."
    git add .
    git commit -m "chore: 自动提交" || echo "无更改"
fi

# 确保使用 main 分支
git branch -M main 2>/dev/null || true

# 检查远程仓库
if ! git remote -v | grep -q origin; then
    echo "🔗 添加远程仓库..."
    git remote add origin https://github.com/$REPO_OWNER/$REPO_NAME.git
else
    git remote set-url origin https://github.com/$REPO_OWNER/$REPO_NAME.git
fi

# 推送
echo ""
echo "🚀 推送到 GitHub..."
echo "仓库：https://github.com/$REPO_OWNER/$REPO_NAME"
echo ""

# 使用 Token 推送
git push https://$GITHUB_TOKEN@github.com/$REPO_OWNER/$REPO_NAME.git main

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ 推送成功！"
    echo ""
    echo "📦 仓库地址："
    echo "https://github.com/$REPO_OWNER/$REPO_NAME"
    echo ""
    echo "📤 下一步：发布到 ClawHub"
    echo "运行：cd $SKILL_DIR && claw skill publish"
    echo ""
else
    echo ""
    echo "❌ 推送失败"
    echo ""
    echo "可能的原因："
    echo "1. Token 无效或过期"
    echo "2. 仓库不存在（请先在 GitHub 创建）"
    echo "3. 权限不足（请检查组织权限）"
    echo ""
    exit 1
fi
