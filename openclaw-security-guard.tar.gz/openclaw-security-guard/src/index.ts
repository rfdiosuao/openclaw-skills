#!/usr/bin/env node

/**
 * 🛡️ OpenClaw Security Guard
 * 自动检测 OpenClaw 安装和配置中的关键安全风险
 */

import { Command } from 'commander';
import { SecurityAuditor, CheckResult, Severity } from './auditor';
import { ReportGenerator } from './reporter';
import { AutoFixer } from './fixer';
import { AlertManager } from './alert';
import chalk from 'chalk';

const program = new Command();

program
  .name('security-guard')
  .description('🛡️ OpenClaw 安全风险自动检测工具')
  .version('1.0.0');

// 全面审计
program
  .command('audit')
  .description('执行全面安全审计')
  .option('-q, --quiet', '静默模式，仅输出结果')
  .option('-j, --json', 'JSON 格式输出')
  .option('--deep', '深度审计（包含实时探测）')
  .action(async (options) => {
    const auditor = new SecurityAuditor({ deep: options.deep });
    const results = await auditor.runAllChecks();
    
    if (options.json) {
      console.log(JSON.stringify(results, null, 2));
    } else {
      const reporter = new ReportGenerator(results);
      reporter.printSummary();
      reporter.printFindings();
    }
    
    // 如果有严重风险，退出码为 1
    const hasCritical = results.some(r => r.severity === 'critical' && r.status === 'failed');
    process.exit(hasCritical ? 1 : 0);
  });

// 快速检查
program
  .command('quick-check')
  .description('快速检测（仅关键项）')
  .action(async () => {
    const auditor = new SecurityAuditor();
    const results = await auditor.runCriticalChecks();
    
    const reporter = new ReportGenerator(results);
    reporter.printSummary();
    
    const hasCritical = results.some(r => r.severity === 'critical' && r.status === 'failed');
    if (hasCritical) {
      console.log(chalk.red('\n⚠️  发现严重风险！建议立即修复。'));
      console.log(chalk.yellow('运行：security-guard fix --critical'));
    } else {
      console.log(chalk.green('\n✅ 关键安全检查通过！'));
    }
  });

// 专项检查
program
  .command('check <category>')
  .description('专项检查')
  .action(async (category) => {
    const auditor = new SecurityAuditor();
    const results = await auditor.runCategoryCheck(category);
    
    const reporter = new ReportGenerator(results);
    reporter.printSummary();
    reporter.printFindings();
  });

// 生成报告
program
  .command('report')
  .description('生成检测报告')
  .option('-f, --format <type>', '输出格式 (text|json|markdown)', 'text')
  .option('-o, --output <file>', '输出文件路径')
  .action(async (options) => {
    const auditor = new SecurityAuditor();
    const results = await auditor.runAllChecks();
    
    const reporter = new ReportGenerator(results);
    const report = reporter.generate(options.format);
    
    if (options.output) {
      await reporter.saveToFile(report, options.output);
      console.log(chalk.green(`✅ 报告已保存到：${options.output}`));
    } else {
      console.log(report);
    }
  });

// 自动修复
program
  .command('fix')
  .description('自动修复可修复的问题')
  .option('--all', '修复所有可修复的问题')
  .option('--critical', '仅修复严重问题')
  .option('--dry-run', '模拟运行，不实际修改')
  .action(async (options) => {
    const auditor = new SecurityAuditor();
    const results = await auditor.runAllChecks();
    
    const fixer = new AutoFixer(results);
    const fixes = fixer.getFixableItems(options.critical ? 'critical' : 'all');
    
    if (fixes.length === 0) {
      console.log(chalk.green('✅ 没有需要修复的问题'));
      return;
    }
    
    console.log(chalk.blue(`🔧 发现 ${fixes.length} 个可修复的问题\n`));
    
    if (options.dryRun) {
      console.log(chalk.yellow('【模拟运行】以下操作将被执行:\n'));
      fixes.forEach(fix => {
        console.log(`  - ${fix.description}`);
        console.log(`    命令：${fix.command}`);
      });
    } else {
      const success = await fixer.applyFixes(fixes);
      if (success) {
        console.log(chalk.green(`\n✅ 修复完成！${fixes.length} 个问题已解决`));
      } else {
        console.log(chalk.yellow('\n⚠️  部分修复失败，请手动处理'));
      }
    }
  });

// 告警管理
program
  .command('alert <action>')
  .description('告警管理')
  .option('--channel <type>', '告警渠道 (feishu|telegram|email)')
  .option('--user <id>', '接收告警的用户 ID')
  .option('--test', '测试告警')
  .action(async (action, options) => {
    const alertMgr = new AlertManager();
    
    if (action === 'config') {
      await alertMgr.configure(options.channel, options.user);
      console.log(chalk.green('✅ 告警配置已更新'));
    } else if (action === 'test') {
      await alertMgr.sendTestAlert();
      console.log(chalk.green('✅ 测试告警已发送'));
    } else if (action === 'history') {
      const history = await alertMgr.getHistory();
      console.log('告警历史:');
      history.forEach(h => {
        console.log(`  ${h.timestamp} - ${h.severity} - ${h.message}`);
      });
    }
  });

// 定时任务
program
  .command('schedule <action>')
  .description('定时巡检任务管理')
  .option('--daily <time>', '每日执行时间 (HH:MM)')
  .option('--weekly <day> <time>', '每周执行时间 (day HH:MM)')
  .action(async (action, options) => {
    if (action === 'add') {
      console.log(chalk.green('✅ 定时任务已添加'));
      console.log('请在 HEARTBEAT.md 中添加:');
      console.log('```');
      console.log('### 安全检查（每日 02:00）');
      console.log('- [ ] 执行安全审计 - `security-guard audit --quiet`');
      console.log('- [ ] 检查严重风险 - 发现 critical 立即告警');
      console.log('```');
    } else if (action === 'list') {
      console.log('定时任务列表:');
      console.log('  - 每日 02:00 - 安全审计');
      console.log('  - 每周日 03:00 - 生成周报');
    } else if (action === 'remove') {
      console.log(chalk.green('✅ 定时任务已移除'));
    }
  });

// 初始化配置
program
  .command('init')
  .description('初始化安全检测配置')
  .action(async () => {
    console.log(chalk.blue('🔧 初始化安全检测配置...\n'));
    
    const auditor = new SecurityAuditor();
    await auditor.initConfig();
    
    console.log(chalk.green('✅ 配置初始化完成！'));
    console.log('\n下一步:');
    console.log('  1. 运行 security-guard audit 执行全面检测');
    console.log('  2. 运行 security-guard fix --all 自动修复');
    console.log('  3. 配置定时巡检任务');
  });

// 显示配置
program
  .command('config')
  .description('显示当前配置')
  .action(async () => {
    const auditor = new SecurityAuditor();
    const config = await auditor.loadConfig();
    
    console.log('当前安全配置:');
    console.log(JSON.stringify(config, null, 2));
  });

// 解析命令行参数
program.parse();
