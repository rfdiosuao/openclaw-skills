/**
 * 自动修复器
 * 提供一键修复功能
 */

import { exec } from 'child_process';
import { promisify } from 'util';
import * as fs from 'fs-extra';
import { CheckResult } from './auditor';

const execAsync = promisify(exec);

export interface FixItem {
  id: string;
  description: string;
  command: string;
  severity: string;
}

export class AutoFixer {
  private results: CheckResult[];

  constructor(results: CheckResult[]) {
    this.results = results;
  }

  /**
   * 获取可修复的项目
   */
  getFixableItems(filter: 'all' | 'critical'): FixItem[] {
    const items: FixItem[] = [];
    
    for (const result of this.results) {
      if (result.status === 'passed') continue;
      if (!result.command && !this.getAutoFixCommand(result.id)) continue;
      
      if (filter === 'critical' && result.severity !== 'critical') continue;
      
      items.push({
        id: result.id,
        description: result.message,
        command: result.command || this.getAutoFixCommand(result.id)!,
        severity: result.severity,
      });
    }
    
    return items;
  }

  /**
   * 应用修复
   */
  async applyFixes(items: FixItem[]): Promise<boolean> {
    let successCount = 0;
    
    for (const item of items) {
      try {
        console.log(`🔧 修复：${item.id}`);
        console.log(`   ${item.description}`);
        
        await this.executeFix(item);
        successCount++;
        
        console.log(`   ✅ 已修复\n`);
      } catch (error) {
        console.log(`   ❌ 修复失败：${error}\n`);
      }
    }
    
    return successCount === items.length;
  }

  /**
   * 获取自动修复命令
   */
  private getAutoFixCommand(checkId: string): string | null {
    const fixCommands: Record<string, string> = {
      'fs.state_dir.perms_world_writable': 'chmod 700 ~/.openclaw',
      'fs.config.perms_writable': 'chmod 600 ~/.openclaw/openclaw.json',
      'gateway.auth_missing': 'openclaw doctor --generate-gateway-token',
    };
    
    return fixCommands[checkId] || null;
  }

  /**
   * 执行修复
   */
  private async executeFix(item: FixItem): Promise<void> {
    // 特殊处理某些修复
    if (item.id === 'fs.state_dir.perms_world_writable') {
      await fs.chmod(process.env.HOME + '/.openclaw', 0o700);
      return;
    }
    
    if (item.id === 'fs.config.perms_writable') {
      await fs.chmod(process.env.HOME + '/.openclaw/openclaw.json', 0o600);
      return;
    }
    
    // 其他修复执行 shell 命令
    if (item.command) {
      await execAsync(item.command);
    }
  }
}
