/**
 * 告警管理器
 * 发送安全告警通知
 */

import * as fs from 'fs-extra';
import * as path from 'path';

export interface AlertConfig {
  channel: string;
  userId: string;
  enabled: boolean;
}

export interface AlertHistory {
  timestamp: string;
  severity: string;
  message: string;
}

export class AlertManager {
  private configPath: string;
  private historyPath: string;

  constructor() {
    const configDir = path.join(process.env.HOME || '', '.openclaw', 'security-guard');
    this.configPath = path.join(configDir, 'alert-config.json');
    this.historyPath = path.join(configDir, 'alert-history.json');
  }

  /**
   * 配置告警
   */
  async configure(channel?: string, userId?: string): Promise<void> {
    const config: AlertConfig = {
      channel: channel || 'feishu',
      userId: userId || '',
      enabled: true,
    };
    
    await fs.ensureDir(path.dirname(this.configPath));
    await fs.writeJson(this.configPath, config, { spaces: 2 });
  }

  /**
   * 发送告警
   */
  async sendAlert(severity: string, message: string, findings: any[]): Promise<void> {
    const config = await this.loadConfig();
    
    if (!config.enabled) {
      return;
    }
    
    // 记录告警历史
    await this.recordHistory(severity, message);
    
    // 根据渠道发送告警
    switch (config.channel) {
      case 'feishu':
        await this.sendFeishuAlert(severity, message, findings, config.userId);
        break;
      case 'telegram':
        await this.sendTelegramAlert(severity, message, findings);
        break;
      default:
        console.log(`📢 安全告警 [${severity.toUpperCase()}]`);
        console.log(message);
    }
  }

  /**
   * 发送测试告警
   */
  async sendTestAlert(): Promise<void> {
    await this.sendAlert('info', '这是一条测试告警', []);
  }

  /**
   * 获取告警历史
   */
  async getHistory(): Promise<AlertHistory[]> {
    try {
      if (await fs.pathExists(this.historyPath)) {
        return await fs.readJson(this.historyPath);
      }
      return [];
    } catch {
      return [];
    }
  }

  /**
   * 记录告警历史
   */
  private async recordHistory(severity: string, message: string): Promise<void> {
    try {
      const history = await this.getHistory();
      history.push({
        timestamp: new Date().toISOString(),
        severity,
        message,
      });
      
      // 只保留最近 100 条
      if (history.length > 100) {
        history.splice(0, history.length - 100);
      }
      
      await fs.writeJson(this.historyPath, history, { spaces: 2 });
    } catch {
      // 忽略错误
    }
  }

  /**
   * 加载配置
   */
  private async loadConfig(): Promise<AlertConfig> {
    try {
      if (await fs.pathExists(this.configPath)) {
        return await fs.readJson(this.configPath);
      }
    } catch {
      // 忽略错误
    }
    
    // 返回默认配置
    return {
      channel: 'feishu',
      userId: '',
      enabled: true,
    };
  }

  /**
   * 发送飞书告警
   */
  private async sendFeishuAlert(
    severity: string,
    message: string,
    findings: any[],
    userId: string
  ): Promise<void> {
    // 这里会调用 feishu_im_user_message 发送告警
    // 实际实现需要在 Skill 中集成飞书 API
    
    const emoji = severity === 'critical' ? '🔴' : severity === 'warning' ? '🟡' : '🔵';
    
    console.log(`${emoji} [飞书告警] ${severity.toUpperCase()}`);
    console.log(message);
    
    if (findings.length > 0) {
      console.log('\n需要修复的问题:');
      findings.forEach((f, i) => {
        console.log(`${i + 1}. ${f.id}: ${f.message}`);
      });
    }
    
    console.log('\n运行以下命令修复:');
    console.log('security-guard fix --critical');
  }

  /**
   * 发送 Telegram 告警
   */
  private async sendTelegramAlert(
    severity: string,
    message: string,
    findings: any[]
  ): Promise<void> {
    const emoji = severity === 'critical' ? '🔴' : severity === 'warning' ? '🟡' : '🔵';
    
    console.log(`${emoji} [Telegram 告警] ${severity.toUpperCase()}`);
    console.log(message);
  }
}
