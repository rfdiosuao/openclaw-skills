/**
 * 安全检测核心逻辑
 * 基于 OpenClaw 官方安全文档实现 16 项核心检测
 */

import * as fs from 'fs-extra';
import * as path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export type Severity = 'critical' | 'warning' | 'info' | 'passed';

export interface CheckResult {
  id: string;
  name: string;
  severity: Severity;
  status: 'passed' | 'failed' | 'warning';
  message: string;
  remediation: string;
  command?: string;
  details?: any;
}

export interface AuditConfig {
  deep: boolean;
  openclawDir: string;
  configPath: string;
}

export class SecurityAuditor {
  private config: AuditConfig;
  private openclawDir: string;
  private configPath: string;

  constructor(options?: { deep?: boolean }) {
    this.openclawDir = process.env.HOME + '/.openclaw';
    this.configPath = path.join(this.openclawDir, 'openclaw.json');
    this.config = {
      deep: options?.deep || false,
      openclawDir: this.openclawDir,
      configPath: this.configPath,
    };
  }

  /**
   * 运行所有检测
   */
  async runAllChecks(): Promise<CheckResult[]> {
    const checks = [
      // 文件系统安全
      () => this.checkFsStateDirPerms(),
      () => this.checkFsConfigPerms(),
      
      // Gateway 安全
      () => this.checkGatewayAuth(),
      () => this.checkGatewayBind(),
      () => this.checkGatewayTailscaleFunnel(),
      
      // 沙箱安全
      () => this.checkSandboxNetworkMode(),
      () => this.checkSandboxMode(),
      
      // 工具安全
      () => this.checkExecSecurity(),
      () => this.checkElevatedMode(),
      () => this.checkToolsProfile(),
      
      // 会话安全
      () => this.checkDMScope(),
      
      // 日志安全
      () => this.checkLoggingRedact(),
      
      // 插件安全
      () => this.checkPluginsAllowList(),
      
      // 浏览器安全
      () => this.checkBrowserSSRF(),
      
      // 节点安全
      () => this.checkNodeCommands(),
    ];

    const results: CheckResult[] = [];
    for (const check of checks) {
      try {
        const result = await check();
        results.push(result);
      } catch (error) {
        results.push({
          id: 'unknown',
          name: '检测执行失败',
          severity: 'warning',
          status: 'warning',
          message: `检测出错：${error}`,
          remediation: '请检查 OpenClaw 安装是否正常',
        });
      }
    }

    return results;
  }

  /**
   * 仅运行关键检测
   */
  async runCriticalChecks(): Promise<CheckResult[]> {
    const criticalChecks = [
      () => this.checkFsConfigPerms(),
      () => this.checkGatewayAuth(),
      () => this.checkGatewayBind(),
      () => this.checkExecSecurity(),
      () => this.checkElevatedMode(),
    ];

    const results: CheckResult[] = [];
    for (const check of criticalChecks) {
      try {
        const result = await check();
        if (result.severity === 'critical') {
          results.push(result);
        }
      } catch (error) {
        // 忽略错误
      }
    }

    return results;
  }

  /**
   * 按类别运行检测
   */
  async runCategoryCheck(category: string): Promise<CheckResult[]> {
    const categoryMap: Record<string, (() => Promise<CheckResult>)[]> = {
      'fs-perms': [() => this.checkFsStateDirPerms(), () => this.checkFsConfigPerms()],
      'network': [() => this.checkGatewayBind(), () => this.checkGatewayTailscaleFunnel()],
      'auth': [() => this.checkGatewayAuth(), () => this.checkDMScope()],
      'sandbox': [() => this.checkSandboxNetworkMode(), () => this.checkSandboxMode()],
      'tools': [() => this.checkExecSecurity(), () => this.checkElevatedMode(), () => this.checkToolsProfile()],
    };

    const checks = categoryMap[category] || [];
    const results: CheckResult[] = [];
    for (const check of checks) {
      try {
        results.push(await check());
      } catch (error) {
        // 忽略错误
      }
    }

    return results;
  }

  /**
   * 检测 1: 状态目录权限
   */
  async checkFsStateDirPerms(): Promise<CheckResult> {
    try {
      const stats = await fs.stat(this.openclawDir);
      const mode = stats.mode & 0o777;
      
      const isWorldWritable = (mode & 0o002) !== 0;
      
      if (isWorldWritable) {
        return {
          id: 'fs.state_dir.perms_world_writable',
          name: '状态目录权限不当',
          severity: 'critical',
          status: 'failed',
          message: `~/.openclaw 目录权限为 ${mode.toString(8)}，其他用户可写`,
          remediation: 'chmod 700 ~/.openclaw',
          command: 'chmod 700 ~/.openclaw',
        };
      }

      return {
        id: 'fs.state_dir.perms_world_writable',
        name: '状态目录权限',
        severity: 'info',
        status: 'passed',
        message: '状态目录权限配置正确',
        remediation: '',
      };
    } catch (error) {
      return {
        id: 'fs.state_dir.perms_world_writable',
        name: '状态目录权限检测',
        severity: 'warning',
        status: 'warning',
        message: `无法访问状态目录：${error}`,
        remediation: '请检查 OpenClaw 是否正确安装',
      };
    }
  }

  /**
   * 检测 2: 配置文件权限
   */
  async checkFsConfigPerms(): Promise<CheckResult> {
    try {
      const stats = await fs.stat(this.configPath);
      const mode = stats.mode & 0o777;
      
      const isWritable = (mode & 0o022) !== 0;
      const isWorldReadable = (mode & 0o004) !== 0;
      
      if (isWritable || isWorldReadable) {
        return {
          id: 'fs.config.perms_writable',
          name: '配置文件权限不当',
          severity: 'critical',
          status: 'failed',
          message: `配置文件权限为 ${mode.toString(8)}，可能被未授权访问`,
          remediation: 'chmod 600 ~/.openclaw/openclaw.json',
          command: 'chmod 600 ~/.openclaw/openclaw.json',
        };
      }

      return {
        id: 'fs.config.perms_writable',
        name: '配置文件权限',
        severity: 'info',
        status: 'passed',
        message: '配置文件权限配置正确',
        remediation: '',
      };
    } catch (error) {
      return {
        id: 'fs.config.perms_writable',
        name: '配置文件权限检测',
        severity: 'warning',
        status: 'warning',
        message: `无法访问配置文件：${error}`,
        remediation: '请检查配置文件是否存在',
      };
    }
  }

  /**
   * 检测 3: Gateway 认证配置
   */
  async checkGatewayAuth(): Promise<CheckResult> {
    try {
      const config = await this.loadConfig();
      const authMode = config.gateway?.auth?.mode;
      
      if (!authMode || authMode === 'none') {
        return {
          id: 'gateway.auth_missing',
          name: 'Gateway 未配置认证',
          severity: 'critical',
          status: 'failed',
          message: 'Gateway 未启用认证，任何人都可以控制你的 OpenClaw',
          remediation: '配置 gateway.auth.mode: "token" 并设置强令牌',
          command: 'openclaw doctor --generate-gateway-token',
        };
      }

      return {
        id: 'gateway.auth_missing',
        name: 'Gateway 认证',
        severity: 'info',
        status: 'passed',
        message: `Gateway 认证模式：${authMode}`,
        remediation: '',
      };
    } catch (error) {
      return {
        id: 'gateway.auth_missing',
        name: 'Gateway 认证检测',
        severity: 'warning',
        status: 'warning',
        message: `无法加载配置：${error}`,
        remediation: '请检查配置文件格式',
      };
    }
  }

  /**
   * 检测 4: Gateway 绑定配置
   */
  async checkGatewayBind(): Promise<CheckResult> {
    try {
      const config = await this.loadConfig();
      const bind = config.gateway?.bind || 'loopback';
      const authMode = config.gateway?.auth?.mode;
      
      if ((bind === '0.0.0.0' || bind === 'any') && !authMode) {
        return {
          id: 'gateway.bind_no_auth',
          name: 'Gateway 绑定配置危险',
          severity: 'critical',
          status: 'failed',
          message: `Gateway 绑定到 ${bind} 但未启用认证`,
          remediation: '配置 gateway.bind: "loopback" 或启用认证',
        };
      }

      if (bind === 'lan') {
        return {
          id: 'gateway.lan_bind',
          name: 'Gateway LAN 绑定',
          severity: 'warning',
          status: 'warning',
          message: 'Gateway 绑定到局域网，确保已启用认证',
          remediation: '建议使用 loopback 或配置强认证',
        };
      }

      return {
        id: 'gateway.bind_no_auth',
        name: 'Gateway 绑定',
        severity: 'info',
        status: 'passed',
        message: `Gateway 绑定模式：${bind}`,
        remediation: '',
      };
    } catch (error) {
      return {
        id: 'gateway.bind_no_auth',
        name: 'Gateway 绑定检测',
        severity: 'warning',
        status: 'warning',
        message: `无法加载配置：${error}`,
        remediation: '请检查配置文件',
      };
    }
  }

  /**
   * 检测 5: Tailscale Funnel
   */
  async checkGatewayTailscaleFunnel(): Promise<CheckResult> {
    try {
      const config = await this.loadConfig();
      const funnelMode = config.gateway?.tailscale?.mode;
      
      if (funnelMode === 'funnel') {
        return {
          id: 'gateway.tailscale_funnel',
          name: 'Tailscale Funnel 启用',
          severity: 'critical',
          status: 'failed',
          message: 'Tailscale Funnel 模式会将 Gateway 暴露到公网',
          remediation: '除非必要，否则禁用 Funnel 模式',
        };
      }

      return {
        id: 'gateway.tailscale_funnel',
        name: 'Tailscale Funnel',
        severity: 'info',
        status: 'passed',
        message: 'Tailscale Funnel 未启用',
        remediation: '',
      };
    } catch (error) {
      return {
        id: 'gateway.tailscale_funnel',
        name: 'Tailscale Funnel 检测',
        severity: 'info',
        status: 'passed',
        message: '未配置 Tailscale',
        remediation: '',
      };
    }
  }

  /**
   * 检测 6: 沙箱网络模式
   */
  async checkSandboxNetworkMode(): Promise<CheckResult> {
    try {
      const config = await this.loadConfig();
      const networkMode = config.agents?.defaults?.sandbox?.docker?.network;
      
      if (networkMode === 'host') {
        return {
          id: 'sandbox.dangerous_network_mode',
          name: '沙箱网络模式危险',
          severity: 'critical',
          status: 'failed',
          message: '沙箱使用 host 网络模式，可访问主机网络',
          remediation: '设置 agents.defaults.sandbox.docker.network: "none"',
        };
      }

      return {
        id: 'sandbox.dangerous_network_mode',
        name: '沙箱网络模式',
        severity: 'info',
        status: 'passed',
        message: `沙箱网络模式：${networkMode || '默认'}`,
        remediation: '',
      };
    } catch (error) {
      return {
        id: 'sandbox.dangerous_network_mode',
        name: '沙箱网络模式检测',
        severity: 'info',
        status: 'passed',
        message: '未配置沙箱网络',
        remediation: '',
      };
    }
  }

  /**
   * 检测 7: 沙箱模式
   */
  async checkSandboxMode(): Promise<CheckResult> {
    try {
      const config = await this.loadConfig();
      const sandboxMode = config.agents?.defaults?.sandbox?.mode;
      
      if (!sandboxMode || sandboxMode === 'off') {
        return {
          id: 'sandbox.mode_off',
          name: '沙箱未启用',
          severity: 'warning',
          status: 'warning',
          message: '沙箱功能未启用，所有工具直接在主机执行',
          remediation: '设置 agents.defaults.sandbox.mode: "non-main" 或 "all"',
        };
      }

      return {
        id: 'sandbox.mode_off',
        name: '沙箱模式',
        severity: 'info',
        status: 'passed',
        message: `沙箱模式：${sandboxMode}`,
        remediation: '',
      };
    } catch (error) {
      return {
        id: 'sandbox.mode_off',
        name: '沙箱模式检测',
        severity: 'info',
        status: 'passed',
        message: '未配置沙箱',
        remediation: '',
      };
    }
  }

  /**
   * 检测 8: Exec 安全配置
   */
  async checkExecSecurity(): Promise<CheckResult> {
    try {
      const config = await this.loadConfig();
      const execSecurity = config.tools?.exec?.security;
      const execAsk = config.tools?.exec?.ask;
      
      if (!execSecurity || execSecurity === 'allow') {
        return {
          id: 'tools.exec.host_sandbox_no_sandbox',
          name: 'Exec 工具未限制',
          severity: 'warning',
          status: 'warning',
          message: 'Exec 工具未配置安全限制，可执行任意命令',
          remediation: '设置 tools.exec.security: "deny" 或 "ask"',
        };
      }

      return {
        id: 'tools.exec.host_sandbox_no_sandbox',
        name: 'Exec 安全配置',
        severity: 'info',
        status: 'passed',
        message: `Exec 安全模式：${execSecurity}`,
        remediation: '',
      };
    } catch (error) {
      return {
        id: 'tools.exec.host_sandbox_no_sandbox',
        name: 'Exec 安全检测',
        severity: 'info',
        status: 'passed',
        message: '未配置 Exec 安全策略',
        remediation: '',
      };
    }
  }

  /**
   * 检测 9: Elevated 模式
   */
  async checkElevatedMode(): Promise<CheckResult> {
    try {
      const config = await this.loadConfig();
      const elevatedEnabled = config.tools?.elevated?.enabled;
      
      if (elevatedEnabled === true) {
        return {
          id: 'tools.elevated.enabled',
          name: 'Elevated 模式已启用',
          severity: 'warning',
          status: 'warning',
          message: 'Elevated 模式绕过沙箱，直接在主机执行',
          remediation: '除非必要，否则设置 tools.elevated.enabled: false',
        };
      }

      return {
        id: 'tools.elevated.enabled',
        name: 'Elevated 模式',
        severity: 'info',
        status: 'passed',
        message: 'Elevated 模式未启用',
        remediation: '',
      };
    } catch (error) {
      return {
        id: 'tools.elevated.enabled',
        name: 'Elevated 模式检测',
        severity: 'info',
        status: 'passed',
        message: '未配置 Elevated 模式',
        remediation: '',
      };
    }
  }

  /**
   * 检测 10: 工具 Profile
   */
  async checkToolsProfile(): Promise<CheckResult> {
    try {
      const config = await this.loadConfig();
      const profile = config.tools?.profile || 'default';
      
      if (profile === 'full') {
        return {
          id: 'tools.profile_full',
          name: '工具权限过高',
          severity: 'warning',
          status: 'warning',
          message: '使用 full 权限配置，所有工具都可用',
          remediation: '使用 messaging 或 minimal 权限配置',
        };
      }

      return {
        id: 'tools.profile_full',
        name: '工具权限配置',
        severity: 'info',
        status: 'passed',
        message: `工具权限配置：${profile}`,
        remediation: '',
      };
    } catch (error) {
      return {
        id: 'tools.profile_full',
        name: '工具权限检测',
        severity: 'info',
        status: 'passed',
        message: '未配置工具权限',
        remediation: '',
      };
    }
  }

  /**
   * 检测 11: DM Scope
   */
  async checkDMScope(): Promise<CheckResult> {
    try {
      const config = await this.loadConfig();
      const dmScope = config.session?.dmScope;
      
      if (!dmScope || dmScope === 'shared') {
        return {
          id: 'session.dm_scope_shared',
          name: 'DM 会话未隔离',
          severity: 'warning',
          status: 'warning',
          message: 'DM 会话共享，多用户可驱动相同工具权限',
          remediation: '设置 session.dmScope: "per-channel-peer"',
        };
      }

      return {
        id: 'session.dm_scope_shared',
        name: 'DM 会话隔离',
        severity: 'info',
        status: 'passed',
        message: `DM 会话模式：${dmScope}`,
        remediation: '',
      };
    } catch (error) {
      return {
        id: 'session.dm_scope_shared',
        name: 'DM 会话检测',
        severity: 'info',
        status: 'passed',
        message: '未配置 DM 会话策略',
        remediation: '',
      };
    }
  }

  /**
   * 检测 12: 日志脱敏
   */
  async checkLoggingRedact(): Promise<CheckResult> {
    try {
      const config = await this.loadConfig();
      const redactSensitive = config.logging?.redactSensitive;
      
      if (redactSensitive === false) {
        return {
          id: 'logging.redact_off',
          name: '日志脱敏未启用',
          severity: 'warning',
          status: 'warning',
          message: '日志未启用敏感信息脱敏',
          remediation: '设置 logging.redactSensitive: true',
        };
      }

      return {
        id: 'logging.redact_off',
        name: '日志脱敏',
        severity: 'info',
        status: 'passed',
        message: '日志脱敏已启用',
        remediation: '',
      };
    } catch (error) {
      return {
        id: 'logging.redact_off',
        name: '日志脱敏检测',
        severity: 'info',
        status: 'passed',
        message: '未配置日志脱敏',
        remediation: '',
      };
    }
  }

  /**
   * 检测 13: 插件允许列表
   */
  async checkPluginsAllowList(): Promise<CheckResult> {
    try {
      const config = await this.loadConfig();
      const pluginsAllow = config.plugins?.allow;
      
      if (!pluginsAllow) {
        return {
          id: 'plugins.allowlist_missing',
          name: '插件未配置允许列表',
          severity: 'info',
          status: 'passed',
          message: '未配置插件允许列表，建议限制可加载的插件',
          remediation: '配置 plugins.allow 列表',
        };
      }

      return {
        id: 'plugins.allowlist_missing',
        name: '插件允许列表',
        severity: 'info',
        status: 'passed',
        message: `已配置插件允许列表：${pluginsAllow.length} 个插件`,
        remediation: '',
      };
    } catch (error) {
      return {
        id: 'plugins.allowlist_missing',
        name: '插件允许列表检测',
        severity: 'info',
        status: 'passed',
        message: '未配置插件策略',
        remediation: '',
      };
    }
  }

  /**
   * 检测 14: 浏览器 SSRF
   */
  async checkBrowserSSRF(): Promise<CheckResult> {
    try {
      const config = await this.loadConfig();
      const allowPrivate = config.browser?.ssrfPolicy?.dangerouslyAllowPrivateNetwork;
      
      if (allowPrivate === true) {
        return {
          id: 'browser.ssrf.allow_private',
          name: '浏览器允许访问私有网络',
          severity: 'warning',
          status: 'warning',
          message: '浏览器可访问私有网络，存在 SSRF 风险',
          remediation: '设置 browser.ssrfPolicy.dangerouslyAllowPrivateNetwork: false',
        };
      }

      return {
        id: 'browser.ssrf.allow_private',
        name: '浏览器 SSRF 策略',
        severity: 'info',
        status: 'passed',
        message: '浏览器私有网络访问已禁用',
        remediation: '',
      };
    } catch (error) {
      return {
        id: 'browser.ssrf.allow_private',
        name: '浏览器 SSRF 检测',
        severity: 'info',
        status: 'passed',
        message: '未配置浏览器 SSRF 策略',
        remediation: '',
      };
    }
  }

  /**
   * 检测 15: 节点命令
   */
  async checkNodeCommands(): Promise<CheckResult> {
    try {
      const config = await this.loadConfig();
      const denyCommands = config.gateway?.nodes?.denyCommands;
      
      if (!denyCommands || !denyCommands.includes('system.run')) {
        return {
          id: 'gateway.nodes.allow_commands_dangerous',
          name: '未禁用危险节点命令',
          severity: 'info',
          status: 'passed',
          message: '未显式禁用 system.run 命令',
          remediation: '配置 gateway.nodes.denyCommands: ["system.run"]',
        };
      }

      return {
        id: 'gateway.nodes.allow_commands_dangerous',
        name: '节点命令限制',
        severity: 'info',
        status: 'passed',
        message: '已禁用危险节点命令',
        remediation: '',
      };
    } catch (error) {
      return {
        id: 'gateway.nodes.allow_commands_dangerous',
        name: '节点命令检测',
        severity: 'info',
        status: 'passed',
        message: '未配置节点命令策略',
        remediation: '',
      };
    }
  }

  /**
   * 加载配置文件
   */
  async loadConfig(): Promise<any> {
    try {
      const configContent = await fs.readFile(this.configPath, 'utf-8');
      // 尝试解析 JSON 或 JSON5
      try {
        return JSON.parse(configContent);
      } catch {
        const JSON5 = (await import('json5')).default;
        return JSON5.parse(configContent);
      }
    } catch (error) {
      return {};
    }
  }

  /**
   * 初始化配置
   */
  async initConfig(): Promise<void> {
    // 创建配置目录
    await fs.ensureDir(this.openclawDir);
    
    // 设置正确权限
    await fs.chmod(this.openclawDir, 0o700);
    
    // 如果配置文件不存在，创建默认配置
    if (!await fs.pathExists(this.configPath)) {
      const defaultConfig = {
        gateway: {
          mode: 'local',
          bind: 'loopback',
          port: 18789,
          auth: {
            mode: 'token',
            token: await this.generateToken(),
          },
        },
        session: {
          dmScope: 'per-channel-peer',
        },
        tools: {
          profile: 'messaging',
          exec: {
            security: 'ask',
            ask: 'always',
          },
          elevated: {
            enabled: false,
          },
        },
        agents: {
          defaults: {
            sandbox: {
              mode: 'non-main',
            },
          },
        },
        logging: {
          redactSensitive: true,
        },
      };
      
      await fs.writeFile(
        this.configPath,
        JSON.stringify(defaultConfig, null, 2),
        { mode: 0o600 }
      );
    }
  }

  /**
   * 生成安全令牌
   */
  private async generateToken(): Promise<string> {
    const { randomBytes } = await import('crypto');
    return randomBytes(32).toString('hex');
  }
}
