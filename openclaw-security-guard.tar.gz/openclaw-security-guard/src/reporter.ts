/**
 * 报告生成器
 * 支持 text、json、markdown 格式
 */

import * as fs from 'fs-extra';
import { CheckResult, Severity } from './auditor';
import chalk from 'chalk';

export class ReportGenerator {
  private results: CheckResult[];

  constructor(results: CheckResult[]) {
    this.results = results;
  }

  /**
   * 打印摘要
   */
  printSummary(): void {
    const summary = this.getSummary();
    
    console.log(chalk.blue('\n🛡️  OpenClaw 安全检测报告'));
    console.log(chalk.blue('═══════════════════════════════════════\n'));
    
    console.log(chalk.white('📊 检测概览'));
    console.log(`- 检测项：${chalk.bold(summary.total.toString())}`);
    console.log(`- ${chalk.red('严重')}: ${chalk.bold(summary.critical.toString())}`);
    console.log(`- ${chalk.yellow('警告')}: ${chalk.bold(summary.warning.toString())}`);
    console.log(`- ${chalk.blue('信息')}: ${chalk.bold(summary.info.toString())}`);
    console.log(`- ${chalk.green('通过')}: ${chalk.bold(summary.passed.toString())}`);
    console.log('');
  }

  /**
   * 打印检测结果
   */
  printFindings(): void {
    const failed = this.results.filter(r => r.status === 'failed');
    const warnings = this.results.filter(r => r.status === 'warning');
    
    if (failed.length > 0) {
      console.log(chalk.red('\n🔴 严重风险'));
      console.log(chalk.red('───────────'));
      failed.forEach((result, index) => {
        console.log(chalk.red(`[${index + 1}] ${result.id}`));
        console.log(chalk.gray(`    问题：${result.message}`));
        console.log(chalk.gray(`    风险：${result.severity}`));
        console.log(chalk.green(`    修复：${result.remediation}`));
        if (result.command) {
          console.log(chalk.yellow(`    命令：${result.command}`));
        }
        console.log('');
      });
    }
    
    if (warnings.length > 0) {
      console.log(chalk.yellow('\n🟡 警告风险'));
      console.log(chalk.yellow('───────────'));
      warnings.forEach((result, index) => {
        console.log(chalk.yellow(`[${index + 1}] ${result.id}`));
        console.log(chalk.gray(`    问题：${result.message}`));
        console.log(chalk.green(`    建议：${result.remediation}`));
        console.log('');
      });
    }
    
    if (failed.length === 0 && warnings.length === 0) {
      console.log(chalk.green('\n✅ 所有安全检查通过！\n'));
    }
  }

  /**
   * 生成报告
   */
  generate(format: 'text' | 'json' | 'markdown'): string {
    switch (format) {
      case 'json':
        return this.generateJSON();
      case 'markdown':
        return this.generateMarkdown();
      default:
        return this.generateText();
    }
  }

  /**
   * 保存到文件
   */
  async saveToFile(content: string, filePath: string): Promise<void> {
    await fs.writeFile(filePath, content, 'utf-8');
  }

  /**
   * 获取摘要统计
   */
  private getSummary(): { total: number; critical: number; warning: number; info: number; passed: number } {
    return {
      total: this.results.length,
      critical: this.results.filter(r => r.severity === 'critical' && r.status === 'failed').length,
      warning: this.results.filter(r => r.status === 'warning').length,
      info: this.results.filter(r => r.severity === 'info').length,
      passed: this.results.filter(r => r.status === 'passed').length,
    };
  }

  /**
   * 生成文本报告
   */
  private generateText(): string {
    const summary = this.getSummary();
    const lines: string[] = [];
    
    lines.push('🛡️  OpenClaw 安全检测报告');
    lines.push('═══════════════════════════════════════');
    lines.push('');
    lines.push('📊 检测概览');
    lines.push(`- 检测项：${summary.total}`);
    lines.push(`- 严重：${summary.critical}`);
    lines.push(`- 警告：${summary.warning}`);
    lines.push(`- 信息：${summary.info}`);
    lines.push(`- 通过：${summary.passed}`);
    lines.push('');
    
    const failed = this.results.filter(r => r.status === 'failed');
    if (failed.length > 0) {
      lines.push('🔴 严重风险');
      lines.push('───────────');
      failed.forEach((result, index) => {
        lines.push(`[${index + 1}] ${result.id}`);
        lines.push(`    问题：${result.message}`);
        lines.push(`    修复：${result.remediation}`);
        lines.push('');
      });
    }
    
    const warnings = this.results.filter(r => r.status === 'warning');
    if (warnings.length > 0) {
      lines.push('🟡 警告风险');
      lines.push('───────────');
      warnings.forEach((result, index) => {
        lines.push(`[${index + 1}] ${result.id}`);
        lines.push(`    问题：${result.message}`);
        lines.push(`    建议：${result.remediation}`);
        lines.push('');
      });
    }
    
    return lines.join('\n');
  }

  /**
   * 生成 JSON 报告
   */
  private generateJSON(): string {
    const summary = this.getSummary();
    const report = {
      timestamp: new Date().toISOString(),
      summary,
      findings: this.results.map(r => ({
        id: r.id,
        name: r.name,
        severity: r.severity,
        status: r.status,
        message: r.message,
        remediation: r.remediation,
        command: r.command || null,
      })),
    };
    
    return JSON.stringify(report, null, 2);
  }

  /**
   * 生成 Markdown 报告
   */
  private generateMarkdown(): string {
    const summary = this.getSummary();
    const lines: string[] = [];
    
    lines.push('# 🛡️ OpenClaw 安全检测报告');
    lines.push('');
    lines.push(`**检测时间:** ${new Date().toLocaleString('zh-CN')}`);
    lines.push('');
    lines.push('## 📊 检测概览');
    lines.push('');
    lines.push('| 项目 | 数量 |');
    lines.push('|------|------|');
    lines.push(`| 检测项 | ${summary.total} |`);
    lines.push(`| 🔴 严重 | ${summary.critical} |`);
    lines.push(`| 🟡 警告 | ${summary.warning} |`);
    lines.push(`| ℹ️ 信息 | ${summary.info} |`);
    lines.push(`| ✅ 通过 | ${summary.passed} |`);
    lines.push('');
    
    const failed = this.results.filter(r => r.status === 'failed');
    if (failed.length > 0) {
      lines.push('## 🔴 严重风险');
      lines.push('');
      failed.forEach((result, index) => {
        lines.push(`### ${index + 1}. ${result.id}`);
        lines.push('');
        lines.push(`- **问题:** ${result.message}`);
        lines.push(`- **修复:** ${result.remediation}`);
        if (result.command) {
          lines.push(`- **命令:** \`${result.command}\``);
        }
        lines.push('');
      });
    }
    
    const warnings = this.results.filter(r => r.status === 'warning');
    if (warnings.length > 0) {
      lines.push('## 🟡 警告风险');
      lines.push('');
      warnings.forEach((result, index) => {
        lines.push(`### ${index + 1}. ${result.id}`);
        lines.push('');
        lines.push(`- **问题:** ${result.message}`);
        lines.push(`- **建议:** ${result.remediation}`);
        lines.push('');
      });
    }
    
    if (failed.length === 0 && warnings.length === 0) {
      lines.push('## ✅ 所有安全检查通过！');
      lines.push('');
      lines.push('恭喜！你的 OpenClaw 配置符合安全最佳实践。');
      lines.push('');
    }
    
    lines.push('---');
    lines.push('');
    lines.push('*报告由 OpenClaw Security Guard 自动生成*');
    
    return lines.join('\n');
  }
}
