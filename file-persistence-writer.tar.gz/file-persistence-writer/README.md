# 🔐 File Persistence Writer - 持久化文件写入助手

> **强制写入底层文件 | 自动验证 | Git 提交凭证 | 防遗忘机制**

[![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)](https://clawhub.ai)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Node](https://img.shields.io/badge/node-%3E%3D18.0.0-brightgreen.svg)](https://nodejs.org)

---

## 📖 简介

**File Persistence Writer** 是一个解决 AI"假装修改"问题的 Skill，确保每次修改都：

- 📝 **真正写入文件** - 禁止仅在上下文中"说修改了"
- ✅ **写入后验证** - 立即读取确认内容一致
- 📦 **Git 提交凭证** - 生成可追溯的 Commit Hash
- 📋 **审计日志** - 完整记录每次修改历史
- 🛡️ **防遗忘机制** - 未验证通过则报错重试

**适用场景：**
- 长期项目，需要可追溯的修改记录
- 重要配置文件，不能出错
- 多人协作，需要审计日志
- AI 容易遗忘的上下文修改

---

## 🚀 快速开始

### 1. 安装 Skill

```bash
claw skill install file-persistence-writer
```

### 2. 基础使用

```typescript
import { createPersistenceWriter } from 'file-persistence-writer';

async function main() {
  const writer = createPersistenceWriter('/workspace');

  // 单次写入
  const receipt = await writer.persist('更新 SOUL.md，在 Core Identity 部分添加新原则');
  
  console.log('写入凭证:', receipt);
  // {
  //   status: 'success',
  //   filePath: 'SOUL.md',
  //   commitHash: 'a1b2c3d4...',
  //   verified: true,
  //   timestamp: 1710234567890
  // }

  // 批量写入
  const receipts = await writer.persistBatch([
    '创建 memory/2026-03-12.md 记录今日工作',
    '更新 USER.md 添加新的项目信息',
    '追加内容到 HEARTBEAT.md 添加新任务'
  ]);
}
```

---

## 📦 API 文档

### 类：FilePersistenceWriter

#### 构造函数

```typescript
const writer = new FilePersistenceWriter(workspaceRoot: string = '/workspace');
```

#### 核心方法

| 方法 | 说明 | 返回值 | 示例 |
|------|------|--------|------|
| `persist(instruction)` | 执行完整写入流程 | Promise<WriteReceipt> | `await writer.persist('更新 SOUL.md')` |
| `persistBatch(instructions)` | 批量写入 | Promise<WriteReceipt[]> | `await writer.persistBatch([...])` |
| `parseInstruction(instruction)` | 解析用户指令 | WriteInstruction | `writer.parseInstruction('创建 test.md')` |
| `writeFile(instruction)` | 执行写入 | Promise<string> | `await writer.writeFile(parsed)` |
| `verifyWrite(filePath, content)` | 验证写入 | Promise<boolean> | `await writer.verifyWrite(path, content)` |
| `commitChanges(files, message)` | Git 提交 | Promise<string> | `await writer.commitChanges([...], 'msg')` |
| `auditLog(entry)` | 记录审计日志 | Promise<void> | `await writer.auditLog(entry)` |
| `getAuditLog(limit)` | 获取审计日志 | Promise<AuditLogEntry[]> | `await writer.getAuditLog(10)` |

---

## 🎬 使用场景

### 场景 1：修改配置文件

```typescript
const writer = createPersistenceWriter();

// 用户指令
const instruction = '更新 openclaw.json，添加新的模型配置';

// 执行写入
const receipt = await writer.persist(instruction);

if (receipt.status === 'success') {
  console.log(`✅ 修改已持久化`);
  console.log(`📁 文件：${receipt.filePath}`);
  console.log(`📦 Commit: ${receipt.commitHash}`);
} else {
  console.error(`❌ 写入失败：${receipt.error}`);
}
```

---

### 场景 2：创建新文件

```typescript
const instruction = '创建 memory/2026-03-12.md，记录今日完成的任务';

const receipt = await writer.persist(instruction);

// 返回凭证
{
  status: 'success',
  filePath: 'memory/2026-03-12.md',
  commitHash: 'a1b2c3d4e5f6...',
  verified: true,
  timestamp: 1710234567890
}
```

---

### 场景 3：批量更新

```typescript
const instructions = [
  '更新 SOUL.md 添加新的核心原则',
  '更新 USER.md 添加项目进展',
  '更新 TOOLS.md 添加新工具配置',
  '创建 memory/2026-03-12.md 记录今日工作'
];

const results = await writer.persistBatch(instructions);

// 查看结果
results.forEach((r, i) => {
  console.log(`${i + 1}. ${r.filePath}: ${r.status} (${r.commitHash})`);
});
```

---

### 场景 4：配合 OpenClaw 工作流

```yaml
# workflows/persistent-write.yaml
name: 持久化文件写入
version: 1.0

triggers:
  - type: manual

steps:
  # 步骤 1：接收用户指令
  - name: receive_instruction
    action: evaluate
    params:
      fn: |
        () => {
          return "更新 SOUL.md，在 Vibe 部分添加新的行为准则";
        }
    output: instruction

  # 步骤 2：执行持久化写入
  - name: persist_write
    action: evaluate
    params:
      fn: |
        (instruction) => {
          const { createPersistenceWriter } = require('file-persistence-writer');
          const writer = createPersistenceWriter('/workspace');
          return writer.persist(instruction);
        }
      input: instruction
    output: receipt

  # 步骤 3：返回凭证
  - name: return_receipt
    action: evaluate
    params:
      fn: |
        (receipt) => {
          if (receipt.status === 'success') {
            return `✅ 写入成功\n文件：${receipt.filePath}\nCommit: ${receipt.commitHash}\n验证：${receipt.verified ? '通过' : '失败'}`;
          } else {
            return `❌ 写入失败：${receipt.error}`;
          }
        }
      input: receipt
    output: final_message
```

---

## 🔧 核心机制

### 1. 强制写入

```typescript
// 禁止上下文假装修改
if (modification_type === 'context_only') {
  throw new Error('❌ 禁止仅在上下文中修改！必须写入底层文件');
}

// 必须调用 write/edit 工具
await write(filePath, content);
```

---

### 2. 写入验证

```typescript
async function writeAndVerify(path: string, content: string) {
  // 写入
  await write(path, content);
  
  // 立即读取验证
  const verified = await read(path);
  
  // 对比内容
  if (verified !== content) {
    throw new Error('❌ 写入验证失败！文件内容不匹配');
  }
  
  return true;
}
```

---

### 3. Git 提交凭证

```typescript
async function commitChanges(files: string[], message: string) {
  // Git add
  await exec(`git add ${files.join(' ')}`);
  
  // Git commit
  await exec(`git commit -m "${message}"`);
  
  // 获取 Commit Hash
  const hash = await exec('git rev-parse HEAD');
  
  if (!hash) {
    throw new Error('❌ Git 提交失败！修改未记录');
  }
  
  return hash;
}
```

---

### 4. 审计日志

```typescript
// 审计日志格式
## 2026-03-12T14:30:00.000Z
- 文件：SOUL.md
- 操作：edit
- Commit: a1b2c3d4e5f6...
- 状态：✅ 验证通过

## 2026-03-12T14:35:00.000Z
- 文件：USER.md
- 操作：append
- Commit: b2c3d4e5f6a7...
- 状态：✅ 验证通过
```

---

## ⚠️ 常见问题

### Q1: 写入验证失败怎么办？

**原因：** 文件被占用、权限问题、内容编码不一致

**解决方案：**
```typescript
// 1. 重试机制
async function writeWithRetry(path: string, content: string, maxRetries = 3) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      await write(path, content);
      const verified = await verifyWrite(path, content);
      if (verified) return true;
    } catch (error) {
      console.log(`重试 ${i + 1}/${maxRetries}`);
    }
  }
  throw new Error('多次重试后仍失败');
}

// 2. 检查文件权限
await exec(`ls -la ${path}`);

// 3. 检查文件编码
const encoding = await detectEncoding(path);
```

---

### Q2: Git 提交失败怎么办？

**原因：** 未初始化 Git、未配置用户信息

**解决方案：**
```bash
# 初始化 Git
git init

# 配置用户信息
git config user.email "you@example.com"
git config user.name "Your Name"

# 检查 Git 状态
git status
```

---

### Q3: 审计日志文件太大怎么办？

**解决方案：**
```typescript
// 1. 限制日志大小
const MAX_LOG_SIZE = 1000; // 最多保留 1000 条

// 2. 定期清理
async function cleanupAuditLog() {
  const logs = await getAuditLog(MAX_LOG_SIZE * 2);
  const recentLogs = logs.slice(0, MAX_LOG_SIZE);
  
  // 重写日志文件
  await write('.persistence-log.md', formatLogs(recentLogs));
}

// 3. 按日期分文件
const logPath = `.persistence-log-${new Date().toISOString().split('T')[0]}.md`;
```

---

## 📊 对比传统方式

| 场景 | 传统方式 | File Persistence Writer |
|------|----------|------------------------|
| **修改配置** | AI 说"已修改"，实际没写 | ✅ 写入 + 验证 + Git 凭证 |
| **更新文档** | 上下文提到，重启就忘 | ✅ 文件落地 + 可追溯 |
| **代码迭代** | 多次对话后不知道改了啥 | ✅ 每次提交有记录 |
| **长期项目** | 修改分散，难以追踪 | ✅ 审计日志完整 |
| **多人协作** | 不知道谁改了什么 | ✅ Commit Hash + 时间戳 |

---

## 📁 项目结构

```
file-persistence-writer/
├── src/
│   └── index.ts           # 核心代码
├── tests/
│   └── index.test.ts      # 单元测试
├── dist/                   # 编译输出
├── skill.json              # Skill 元数据
├── package.json            # NPM 配置
├── tsconfig.json           # TypeScript 配置
├── README.md               # 完整文档
├── SKILL.md                # ClawHub 格式说明
└── .gitignore              # Git 忽略配置
```

---

## 🚀 发布到 ClawHub

### 步骤 1：登录

```bash
claw login --token <your_api_key>
```

### 步骤 2：发布

```bash
cd file-persistence-writer
claw skill publish
```

### 步骤 3：验证

```bash
claw skill my
```

---

## 📚 扩展阅读

- [OpenClaw 官方文档](https://docs.openclaw.ai)
- [Git 最佳实践](https://git-scm.com/book)
- [文件系统设计](https://en.wikipedia.org/wiki/File_system)

---

## 🤝 社区支持

| 渠道 | 链接 | 说明 |
|------|------|------|
| GitHub Issues | https://github.com/rfdiosuao/openclaw-skills/issues | 问题反馈 |
| OpenClaw Discord | https://discord.com/invite/clawd | 技术交流 |
| ClawHub 社区 | https://clawhub.ai | 案例分享 |

---

## 📝 更新日志

### v1.0.0 (2026-03-12)

**✨ 初始版本发布**

- ✅ 支持文件写入强制验证
- ✅ 支持 Git 提交生成凭证
- ✅ 支持审计日志记录
- ✅ 支持批量写入
- ✅ 完整的 TypeScript 类型定义
- ✅ 包含单元测试和文档

---

## 📄 许可证

MIT License © 2026 郑宇航

---

**作者**: 郑宇航  
**GitHub**: https://github.com/rfdiosuao/openclaw-skills  
**ClawHub**: https://clawhub.ai  
**最后更新**: 2026-03-12

---

## 🏷️ 标签

#OpenClaw #文件写入 #持久化 #验证 #Git 提交 #防遗忘 #审计日志 #开发工具
