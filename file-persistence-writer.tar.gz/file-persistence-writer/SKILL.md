# 🔐 File Persistence Writer - 持久化文件写入助手

> **强制写入底层文件 | 自动验证 | Git 提交凭证 | 防遗忘机制**

**作者**: 郑宇航  
**版本**: 1.0.0  
**分类**: 开发工具  
**标签**: #文件写入 #持久化 #验证 #Git 提交 #防遗忘 #审计日志

---

## 🎯 功能特性

- 📝 **强制写入文件** - 禁止仅在上下文中"假装修改"
- ✅ **写入后验证** - 立即读取确认内容一致
- 📦 **Git 提交凭证** - 生成可追溯的 Commit Hash
- 📋 **审计日志** - 完整记录每次修改历史
- 🛡️ **防遗忘机制** - 未验证通过则报错重试
- 📦 **批量写入** - 支持一次处理多个文件

---

## 🚀 快速开始

### 安装

```bash
claw skill install file-persistence-writer
```

### 基础使用

```typescript
import { createPersistenceWriter } from 'file-persistence-writer';

async function main() {
  const writer = createPersistenceWriter('/workspace');

  // 单次写入
  const receipt = await writer.persist('更新 SOUL.md，添加新的核心原则');
  
  console.log('写入凭证:', receipt);
  // {
  //   status: 'success',
  //   filePath: 'SOUL.md',
  //   commitHash: 'a1b2c3d4...',
  //   verified: true,
  //   timestamp: 1710234567890
  // }
}
```

---

## 📦 API 参考

### 创建写入器

```typescript
const writer = createPersistenceWriter(workspaceRoot: string = '/workspace');
```

### 核心方法

| 方法 | 说明 |
|------|------|
| `persist(instruction)` | 执行完整写入流程（解析→写入→验证→提交→日志） |
| `persistBatch(instructions)` | 批量写入多个文件 |
| `parseInstruction(instruction)` | 解析用户指令，提取文件路径和操作类型 |
| `getAuditLog(limit)` | 获取最近 N 条审计日志 |

---

## 🎬 使用场景

### 场景 1：修改配置文件

```typescript
const receipt = await writer.persist('更新 openclaw.json 添加新模型配置');

if (receipt.status === 'success') {
  console.log(`✅ 修改已持久化，Commit: ${receipt.commitHash}`);
}
```

---

### 场景 2：批量更新

```typescript
const results = await writer.persistBatch([
  '更新 SOUL.md 添加新的核心原则',
  '更新 USER.md 添加项目进展',
  '创建 memory/2026-03-12.md 记录今日工作'
]);
```

---

### 场景 3：OpenClaw 工作流集成

```yaml
steps:
  - name: persist_write
    action: evaluate
    params:
      fn: |
        (instruction) => {
          const { createPersistenceWriter } = require('file-persistence-writer');
          const writer = createPersistenceWriter('/workspace');
          return writer.persist(instruction);
        }
    output: receipt
```

---

## 🔧 核心机制

### 1. 强制写入
```typescript
// 禁止上下文假装修改
if (modification_type === 'context_only') {
  throw new Error('❌ 必须写入底层文件！');
}
```

### 2. 写入验证
```typescript
// 写入后立即读取对比
await write(path, content);
const verified = await read(path);
if (verified !== content) throw new Error('验证失败');
```

### 3. Git 提交凭证
```typescript
// 生成可追溯的 Commit Hash
const hash = await exec('git rev-parse HEAD');
```

### 4. 审计日志
```markdown
## 2026-03-12T14:30:00.000Z
- 文件：SOUL.md
- 操作：edit
- Commit: a1b2c3d4...
- 状态：✅ 验证通过
```

---

## ⚠️ 注意事项

1. **Git 初始化** - 确保工作区已初始化 Git 仓库
2. **文件权限** - 确保有写入权限
3. **编码一致** - 注意文件编码（UTF-8 推荐）
4. **大文件处理** - 建议分批写入大文件

---

## 📚 依赖

- Node.js >= 18.0.0
- Git（用于提交凭证）

---

## 📄 许可证

MIT License

---

**完整文档**: https://github.com/rfdiosuao/openclaw-skills/tree/main/file-persistence-writer
