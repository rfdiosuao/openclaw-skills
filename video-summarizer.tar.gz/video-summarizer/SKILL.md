# 🎬 Video Summarizer - 视频文案智能总结助手

> **自动纠错 + 语境补充 + 文章感总结 | 一眼看懂视频内容**

**作者**: 郑宇航  
**版本**: 1.0.0  
**分类**: 内容创作  
**标签**: #视频总结 #ASR 纠错 #智能摘要 #内容理解 #文案提取

---

## 🎯 功能特性

- 🔧 **ASR 自动纠错** - 修复同音字、专业术语、人名地名的识别错误
- 📝 **语境补充** - 根据上下文补全缺失内容，让文案更通顺
- ✍️ **文章感总结** - 生成直白明了、有结构感的总结
- 🎯 **关键提取** - 自动识别核心要点、行动建议、涉及话题
- 📦 **批量处理** - 支持一次处理多个视频文案

---

## 🚀 快速开始

### 安装

```bash
claw skill install video-summarizer
```

### 基础使用

```typescript
import { createVideoSummarizer } from 'video-summarizer';

const summarizer = createVideoSummarizer();

const asrText = `
  今天我们来学习 openclaw 的配置方法。
  openclaw 是一个 A I 自动化工具，可以连接非书多维表格。
  首先，你需要安装 node js 环境。
  其次，配置 G I T H U B Token。
  最后，创建工作流就可以了。
`;

const summary = await summarizer.summarize(asrText);

console.log('📌 标题:', summary.title);
console.log('💬 一句话:', summary.oneLiner);
console.log('🎯 要点:', summary.keyPoints);
console.log('📝 总结:\n', summary.fullSummary);
```

---

## 📦 API 参考

### 创建总结器

```typescript
const summarizer = createVideoSummarizer({
  style: 'concise',        // 简洁/详细/专业
  maxLength: 500,          // 最大字数
  includeTimestamp: false, // 是否包含时间戳
  autoCorrect: true        // 是否自动纠错
});
```

### 核心方法

| 方法 | 说明 |
|------|------|
| `summarize(text, config?)` | 完整总结流程（纠错→提取→生成） |
| `correctASR(text)` | ASR 纠错，返回修正后文本和纠错记录 |
| `extractKeyPoints(text)` | 提取关键要点 |
| `generateOneLiner(text, points)` | 生成一句话概括 |
| `extractTopics(text)` | 提取涉及话题 |
| `summarizeBatch(texts, config?)` | 批量总结多个视频 |

---

## 🎬 使用场景

### 场景 1：视频教程总结

```typescript
const summary = await summarizer.summarize(tutorialASR);
// 输出：标题 + 一句话 + 关键要点 + 完整总结
```

---

### 场景 2：会议录音整理

```typescript
const summarizer = createVideoSummarizer({ 
  style: 'professional',
  includeTimestamp: true 
});

const summary = await summarizer.summarize(meetingASR);
// 输出包含行动建议
```

---

### 场景 3：批量处理

```typescript
const summaries = await summarizer.summarizeBatch([
  '视频 1 文案...',
  '视频 2 文案...',
  '视频 3 文案...'
]);
```

---

## 🔧 ASR 纠错能力

| 错误类型 | 示例 | 修复 |
|----------|------|------|
| 同音字 | openclaw → OpenClaw | ✅ |
| 专业术语 | A P I → API | ✅ |
| 技术名词 | java script → JavaScript | ✅ |
| 公司名称 | OpenAI → OpenAI | ✅ |
| 语境问题 | 多余空格、重复词 | ✅ |

---

## ✍️ 文章感总结

**输出结构：**
```markdown
## 📌 核心内容
一句话概括视频主题

## 🎯 关键要点
1. 要点 1
2. 要点 2
3. 要点 3

## 💡 总结
根据内容类型自动生成结尾
```

**特点：**
- ✅ 直白明了，不说废话
- ✅ 结构化，便于快速浏览
- ✅ 一眼看懂核心内容

---

## ⚠️ 注意事项

1. **ASR 质量** - 原始文案质量影响总结效果
2. **专业领域** - 特定领域术语需扩展纠错词典
3. **长度控制** - 超长文案建议分段处理
4. **语言支持** - 目前主要支持中文

---

## 📚 依赖

- Node.js >= 18.0.0

---

## 📄 许可证

MIT License

---

**完整文档**: https://github.com/rfdiosuao/openclaw-skills/tree/main/video-summarizer
