# 🎬 Video Summarizer - 视频文案智能总结助手

> **自动纠错 + 语境补充 + 文章感总结 | 一眼看懂视频内容**

[![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)](https://clawhub.ai)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Node](https://img.shields.io/badge/node-%3E%3D18.0.0-brightgreen.svg)](https://nodejs.org)

---

## 📖 简介

**Video Summarizer** 是一个智能视频文案总结工具，专门解决 ASR 提取文案的问题：

- 🔧 **自动纠错** - 修复同音字、专业术语、人名地名的 ASR 识别错误
- 📝 **语境补充** - 根据上下文补全缺失内容，让文案更通顺
- ✍️ **文章感总结** - 生成直白明了、有结构感的总结，一眼看懂核心内容
- 🎯 **关键提取** - 自动识别核心要点、行动建议、涉及话题

**适用场景：**
- 视频教程快速回顾
- 会议录音整理总结
- 网课内容精华提取
- 直播回放要点梳理
- 自媒体文案二次创作

---

## 🚀 快速开始

### 1. 安装 Skill

```bash
claw skill install video-summarizer
```

### 2. 基础使用

```typescript
import { createVideoSummarizer } from 'video-summarizer';

async function main() {
  const summarizer = createVideoSummarizer();

  // ASR 提取的原始文案（包含错误）
  const asrText = `
    今天我们来学习 openclaw 的配置方法。
    openclaw 是一个 A I 自动化工具，可以连接非书多维表格。
    首先，你需要安装 node js 环境。
    其次，配置 G I T H U B Token。
    最后，创建工作流就可以了。
    总之，openclaw 能帮你节省大量时间。
  `;

  // 生成总结
  const summary = await summarizer.summarize(asrText);

  console.log('📌 标题:', summary.title);
  console.log('💬 一句话:', summary.oneLiner);
  console.log('🎯 要点:', summary.keyPoints);
  console.log('📝 总结:\n', summary.fullSummary);
}
```

### 3. 输出效果

```
📌 标题：OpenClaw：OpenClaw 是一个 AI 自动化工具，可以连接飞书多维表格...

💬 一句话：OpenClaw 是一个 AI 自动化工具，可以连接飞书多维表格...

🎯 要点：
1. openclaw 是一个 AI 自动化工具，可以连接飞书多维表格
2. 首先，你需要安装 Node.js 环境
3. 其次，配置 GitHub Token
4. 最后，创建工作流就可以了
5. openclaw 能帮你节省大量时间

📝 总结：
## 📌 核心内容
OpenClaw 是一个 AI 自动化工具，可以连接飞书多维表格...

## 🎯 关键要点
1. openclaw 是一个 AI 自动化工具，可以连接飞书多维表格
2. 首先，你需要安装 Node.js 环境
3. 其次，配置 GitHub Token
4. 最后，创建工作流就可以了
5. openclaw 能帮你节省大量时间

## 💡 总结
总的来说，这是一个实用的教程，按照上述步骤操作即可掌握核心技能。
建议动手实践，加深理解。
```

---

## 📦 API 文档

### 类：VideoSummarizer

#### 构造函数参数

```typescript
interface SummarizerConfig {
  style?: 'concise' | 'detailed' | 'professional';  // 总结风格
  maxLength?: number;                                // 最大字数
  includeTimestamp?: boolean;                        // 是否包含时间戳
  autoCorrect?: boolean;                             // 是否自动纠错
}
```

#### 核心方法

| 方法 | 说明 | 返回值 | 示例 |
|------|------|--------|------|
| `summarize(text, config?)` | 完整总结流程 | Promise<VideoSummary> | `await summarizer.summarize(text)` |
| `correctASR(text)` | ASR 纠错 | {corrected, corrections} | `summarizer.correctASR(text)` |
| `extractKeyPoints(text)` | 提取关键要点 | string[] | `summarizer.extractKeyPoints(text)` |
| `generateOneLiner(text, points)` | 生成一句话概括 | string | `summarizer.generateOneLiner(text, points)` |
| `extractTopics(text)` | 提取涉及话题 | string[] | `summarizer.extractTopics(text)` |
| `summarizeBatch(texts, config?)` | 批量总结 | Promise<VideoSummary[]> | `await summarizer.summarizeBatch([...])` |

---

## 🎬 使用场景

### 场景 1：视频教程总结

```typescript
const summarizer = createVideoSummarizer({ 
  style: 'concise',
  autoCorrect: true 
});

// 编程教程 ASR 文案
const tutorialText = `
  大家好，今天我们来学习 java script 的基础知识。
  首先，你需要安装 node js 环境。
  其次，创建一个 package 点 json 文件。
  然后，编写你的第一个 hello world 程序。
  总之，java script 是一门非常灵活的编程语言。
`;

const summary = await summarizer.summarize(tutorialText);

console.log(summary.fullSummary);
```

---

### 场景 2：会议录音整理

```typescript
const summarizer = createVideoSummarizer({ 
  style: 'professional',
  includeTimestamp: true 
});

const meetingText = `
  本次会议主要讨论 Q2 季度的 O K R 目标。
  首先是 G M V 目标，我们计划达到 5000 万。
  其次是 D A U 目标，目标是 100 万日活。
  最后是 M A U，要达到 300 万月活。
  各团队需要在下周五之前提交详细计划。
`;

const summary = await summarizer.summarize(meetingText);

// 输出包含行动建议
console.log('行动建议:', summary.actionItems);
```

---

### 场景 3：网课内容精华

```typescript
const summarizer = createVideoSummarizer({ 
  style: 'detailed',
  maxLength: 1000 
});

const courseText = `
  今天我们讲解机器学习的基础概念。
  机器学习是人工智能的一个分支。
  它包括监督学习、非监督学习和强化学习三种类型。
  监督学习需要标注数据，比如分类和回归问题。
  非监督学习不需要标注，比如聚类和降维。
  强化学习通过奖励机制来训练模型。
  常见的算法有线性回归、逻辑回归、决策树、随机森林等。
  深度学习是机器学习的子集，使用神经网络模型。
`;

const summary = await summarizer.summarize(courseText);

console.log('话题:', summary.topics);
console.log('要点数量:', summary.keyPoints.length);
```

---

### 场景 4：批量处理多个视频

```typescript
const summarizer = createVideoSummarizer();

const videoTexts = [
  '视频 1 的 ASR 文案...',
  '视频 2 的 ASR 文案...',
  '视频 3 的 ASR 文案...'
];

const summaries = await summarizer.summarizeBatch(videoTexts);

summaries.forEach((summary, index) => {
  console.log(`视频${index + 1}: ${summary.title}`);
});
```

---

## 🔧 ASR 纠错能力

### 自动修复的错误类型

| 类型 | 示例 | 修复后 |
|------|------|--------|
| **同音字** | openclaw → OpenClaw | ✅ |
| **专业术语** | A P I → API | ✅ |
| **人名地名** | 马斯克 → 马斯克 | ✅ |
| **技术名词** | java script → JavaScript | ✅ |
| **公司名称** | OpenAI → OpenAI | ✅ |
| **语境纠错** | 多余空格、重复词 | ✅ |

### 自定义纠错词典

```typescript
const summarizer = createVideoSummarizer();

// 可以扩展纠错词典
const customCorrections = {
  '我的项目名': 'MyProject',
  '特定术语': 'SpecificTerm',
  // ...
};

// 在 correctASR 方法中集成
```

---

## ✍️ 文章感总结特点

### 1. 结构化输出

```markdown
## 📌 核心内容
一句话概括视频主题

## 🎯 关键要点
1. 要点 1
2. 要点 2
3. 要点 3

## 💡 总结
根据内容类型自动生成结尾
- 教程类：建议动手实践
- 评测类：建议理性选择
- 新闻类：建议持续关注
- 观点类：建议独立思考
```

---

### 2. 直白明了

**错误示例（机器感）：**
> 本视频内容涉及多个方面的技术讲解，包括但不限于 OpenClaw 工具的配置与使用方法...

**正确示例（文章感）：**
> OpenClaw 是一个自动化工具，可以连接飞书。安装后配置 API 密钥，就能创建工作流，帮你节省时间。

---

### 3. 一眼看懂

- ✅ **标题包含核心话题** - 知道讲什么
- ✅ **一句话概括主旨** - 10 秒了解内容
- ✅ **要点编号清晰** - 快速浏览重点
- ✅ **结尾有总结升华** - 完整闭环

---

## ⚠️ 常见问题

### Q1: ASR 纠错不准确怎么办？

**解决方案：**
```typescript
// 1. 扩展纠错词典
const customCorrections = {
  '特定错误': '正确写法',
  // ...
};

// 2. 关闭自动纠错，手动处理
const summarizer = createVideoSummarizer({ autoCorrect: false });
const corrected = manuallyCorrect(text);
const summary = await summarizer.summarize(corrected);
```

---

### Q2: 总结太长/太短怎么办？

**解决方案：**
```typescript
// 控制最大字数
const summarizer = createVideoSummarizer({ 
  maxLength: 300,  // 300 字以内
  style: 'concise' // 简洁模式
});

// 或者详细模式
const summarizer = createVideoSummarizer({ 
  style: 'detailed',
  maxLength: 1000 
});
```

---

### Q3: 如何提取行动建议？

**解决方案：**
```typescript
const summarizer = createVideoSummarizer();
const summary = await summarizer.summarize(text);

// 从关键要点中筛选行动建议
const actionItems = summary.keyPoints.filter(point => 
  point.includes('应该') || 
  point.includes('建议') || 
  point.includes('需要') ||
  point.includes('必须')
);

console.log('行动建议:', actionItems);
```

---

## 📊 对比传统总结

| 维度 | 传统摘要 | Video Summarizer |
|------|----------|------------------|
| **ASR 纠错** | ❌ 需要手动修正 | ✅ 自动修复 |
| **语境理解** | ❌ 机械截取 | ✅ 智能补充 |
| **文章感** | ❌ 生硬拼凑 | ✅ 自然流畅 |
| **结构化** | ❌ 纯文本 | ✅ 分级标题 + 要点 |
| **可读性** | ⭐⭐ | ⭐⭐⭐⭐⭐ |

---

## 📁 项目结构

```
video-summarizer/
├── src/
│   └── index.ts           # 核心代码
├── tests/
│   └── index.test.ts      # 单元测试
├── dist/                   # 编译输出
├── skill.json              # Skill 元数据
├── package.json            # NPM 配置
├── tsconfig.json           # TypeScript 配置
├── README.md               # 完整文档
├── SKILL.md                # ClawHub 格式说明
└── .gitignore              # Git 忽略配置
```

---

## 🚀 发布到 ClawHub

### 步骤 1：登录

```bash
claw login --token <your_api_key>
```

### 步骤 2：发布

```bash
cd video-summarizer
claw skill publish
```

### 步骤 3：验证

```bash
claw skill my
```

---

## 📚 扩展阅读

- [OpenClaw 官方文档](https://docs.openclaw.ai)
- [ASR 技术原理](https://en.wikipedia.org/wiki/Speech_recognition)
- [文本摘要技术](https://en.wikipedia.org/wiki/Automatic_summarization)

---

## 🤝 社区支持

| 渠道 | 链接 | 说明 |
|------|------|------|
| GitHub Issues | https://github.com/rfdiosuao/openclaw-skills/issues | 问题反馈 |
| OpenClaw Discord | https://discord.com/invite/clawd | 技术交流 |
| ClawHub 社区 | https://clawhub.ai | 案例分享 |

---

## 📝 更新日志

### v1.0.0 (2026-03-12)

**✨ 初始版本发布**

- ✅ 支持 ASR 自动纠错（同音字、术语、人名）
- ✅ 支持语境补充修复
- ✅ 生成文章感总结（结构化 + 直白）
- ✅ 自动提取关键要点和话题
- ✅ 支持批量处理多个视频
- ✅ 完整的 TypeScript 类型定义
- ✅ 包含单元测试和文档

---

## 📄 许可证

MIT License © 2026 郑宇航

---

**作者**: 郑宇航  
**GitHub**: https://github.com/rfdiosuao/openclaw-skills  
**ClawHub**: https://clawhub.ai  
**最后更新**: 2026-03-12

---

## 🏷️ 标签

#OpenClaw #视频总结 #ASR 纠错 #智能摘要 #内容理解 #文案提取 #自动化 #内容创作
